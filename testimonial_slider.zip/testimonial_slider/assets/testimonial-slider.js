jQuery(document).ready(function($) {
    'use strict';
    
    class TestimonialSlider {
        constructor(container) {
            this.container = $(container);
            this.slides = this.container.find('.testimonial-slide');
            this.dots = this.container.find('.dot');
            this.prevBtn = this.container.find('.prev-btn');
            this.nextBtn = this.container.find('.next-btn');
            this.progressFill = this.container.find('.progress-fill');
            
            this.currentIndex = 0;
            this.totalSlides = this.slides.length;
            this.isAutoPlaying = this.container.data('autoplay') !== false;
            this.speed = parseInt(this.container.data('speed')) || 6000;
            this.autoplayTimer = null;
            this.progressTimer = null;
            
            this.init();
        }
        
        init() {
            this.bindEvents();
            this.updateProgressBar();
            
            if (this.isAutoPlaying) {
                this.startAutoplay();
            }
        }
        
        bindEvents() {
            // Navigation buttons
            this.prevBtn.on('click', () => this.goToPrevious());
            this.nextBtn.on('click', () => this.goToNext());
            
            // Dots navigation
            this.dots.on('click', (e) => {
                const index = parseInt($(e.target).data('index'));
                this.goToSlide(index);
            });
            
            // Pause autoplay on hover
            this.container.on('mouseenter', () => this.pauseAutoplay());
            this.container.on('mouseleave', () => this.resumeAutoplay());
            
            // Touch/swipe support for mobile
            this.addTouchSupport();
        }
        
        addTouchSupport() {
            let startX = 0;
            let endX = 0;
            
            this.container.on('touchstart', (e) => {
                startX = e.originalEvent.touches[0].clientX;
            });
            
            this.container.on('touchend', (e) => {
                endX = e.originalEvent.changedTouches[0].clientX;
                this.handleSwipe(startX, endX);
            });
        }
        
        handleSwipe(startX, endX) {
            const threshold = 50;
            const diff = startX - endX;
            
            if (Math.abs(diff) > threshold) {
                if (diff > 0) {
                    this.goToNext();
                } else {
                    this.goToPrevious();
                }
            }
        }
        
        goToNext() {
            const nextIndex = (this.currentIndex + 1) % this.totalSlides;
            this.goToSlide(nextIndex);
        }
        
        goToPrevious() {
            const prevIndex = this.currentIndex === 0 ? this.totalSlides - 1 : this.currentIndex - 1;
            this.goToSlide(prevIndex);
        }
        
        goToSlide(index) {
            if (index === this.currentIndex) return;
            
            // Update slides
            this.slides.removeClass('active');
            this.slides.eq(index).addClass('active');
            
            // Update dots
            this.dots.removeClass('active');
            this.dots.eq(index).addClass('active');
            
            this.currentIndex = index;
            this.updateProgressBar();
            
            // Restart autoplay if it was running
            if (this.isAutoPlaying) {
                this.restartAutoplay();
            }
        }
        
        updateProgressBar() {
            const progress = ((this.currentIndex + 1) / this.totalSlides) * 100;
            this.progressFill.css('width', progress + '%');
        }
        
        startAutoplay() {
            if (!this.isAutoPlaying) return;
            
            this.autoplayTimer = setInterval(() => {
                this.goToNext();
            }, this.speed);
        }
        
        pauseAutoplay() {
            if (this.autoplayTimer) {
                clearInterval(this.autoplayTimer);
                this.autoplayTimer = null;
            }
        }
        
        resumeAutoplay() {
            if (this.isAutoPlaying && !this.autoplayTimer) {
                this.startAutoplay();
            }
        }
        
        restartAutoplay() {
            this.pauseAutoplay();
            this.startAutoplay();
        }
        
        destroy() {
            this.pauseAutoplay();
            this.container.off();
            this.prevBtn.off();
            this.nextBtn.off();
            this.dots.off();
        }
    }
    
    // Initialize all testimonial sliders on the page
    $('.testimonial-slider-container').each(function() {
        new TestimonialSlider(this);
    });
    
    // Reinitialize sliders when content is dynamically loaded (for page builders)
    $(document).on('widget-added widget-updated', function() {
        setTimeout(function() {
            $('.testimonial-slider-container').each(function() {
                if (!$(this).data('testimonial-slider-initialized')) {
                    new TestimonialSlider(this);
                    $(this).data('testimonial-slider-initialized', true);
                }
            });
        }, 100);
    });
});