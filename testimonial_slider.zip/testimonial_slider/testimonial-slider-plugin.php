<?php
/**
 * Plugin Name: Testimonial Slider Pro
 * Plugin URI: https://yourwebsite.com/testimonial-slider-pro
 * Description: A beautiful testimonial slider with responsive design and smooth animations. Now with custom post type support.
 * Version: 1.1.0
 * Author: S M Mehedi hasan
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * Text Domain: testimonial-slider-pro
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class TestimonialSliderPro {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('testimonial_slider', array($this, 'testimonial_slider_shortcode'));
        add_action('wp_ajax_get_testimonials', array($this, 'get_testimonials'));
        add_action('wp_ajax_nopriv_get_testimonials', array($this, 'get_testimonials'));
        
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        
        // Register custom post type
        add_action('init', array($this, 'register_testimonial_post_type'));
        
        // Add meta boxes
        add_action('add_meta_boxes', array($this, 'add_testimonial_meta_boxes'));
        add_action('save_post', array($this, 'save_testimonial_meta'));
        
        // Add image size for testimonials
        add_action('after_setup_theme', array($this, 'add_image_size'));
    }
    
    public function init() {
        // Plugin initialization
        load_plugin_textdomain('testimonial-slider-pro', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('testimonial-slider-pro-css', plugin_dir_url(__FILE__) . 'assets/testimonial-slider.css', array(), '1.1.0');
        wp_enqueue_script('testimonial-slider-pro-js', plugin_dir_url(__FILE__) . 'assets/testimonial-slider.js', array('jquery'), '1.1.0', true);
        
        // Localize script for AJAX
        wp_localize_script('testimonial-slider-pro-js', 'testimonial_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('testimonial_nonce')
        ));
    }
    
    public function register_testimonial_post_type() {
        $labels = array(
            'name'                  => _x('Testimonials', 'Post Type General Name', 'testimonial-slider-pro'),
            'singular_name'         => _x('Testimonial', 'Post Type Singular Name', 'testimonial-slider-pro'),
            'menu_name'             => __('Testimonials', 'testimonial-slider-pro'),
            'name_admin_bar'        => __('Testimonial', 'testimonial-slider-pro'),
            'archives'              => __('Testimonial Archives', 'testimonial-slider-pro'),
            'attributes'            => __('Testimonial Attributes', 'testimonial-slider-pro'),
            'parent_item_colon'     => __('Parent Testimonial:', 'testimonial-slider-pro'),
            'all_items'             => __('All Testimonials', 'testimonial-slider-pro'),
            'add_new_item'          => __('Add New Testimonial', 'testimonial-slider-pro'),
            'add_new'              => __('Add New', 'testimonial-slider-pro'),
            'new_item'             => __('New Testimonial', 'testimonial-slider-pro'),
            'edit_item'            => __('Edit Testimonial', 'testimonial-slider-pro'),
            'update_item'          => __('Update Testimonial', 'testimonial-slider-pro'),
            'view_item'            => __('View Testimonial', 'testimonial-slider-pro'),
            'view_items'           => __('View Testimonials', 'testimonial-slider-pro'),
            'search_items'         => __('Search Testimonial', 'testimonial-slider-pro'),
            'not_found'            => __('Not found', 'testimonial-slider-pro'),
            'not_found_in_trash'   => __('Not found in Trash', 'testimonial-slider-pro'),
            'featured_image'       => __('Client Image', 'testimonial-slider-pro'),
            'set_featured_image'   => __('Set client image', 'testimonial-slider-pro'),
            'remove_featured_image' => __('Remove client image', 'testimonial-slider-pro'),
            'use_featured_image'   => __('Use as client image', 'testimonial-slider-pro'),
            'insert_into_item'     => __('Insert into testimonial', 'testimonial-slider-pro'),
            'uploaded_to_this_item' => __('Uploaded to this testimonial', 'testimonial-slider-pro'),
            'items_list'           => __('Testimonials list', 'testimonial-slider-pro'),
            'items_list_navigation' => __('Testimonials list navigation', 'testimonial-slider-pro'),
            'filter_items_list'     => __('Filter testimonials list', 'testimonial-slider-pro'),
        );
        
        $args = array(
            'label'                 => __('Testimonial', 'testimonial-slider-pro'),
            'description'           => __('Client testimonials for your website', 'testimonial-slider-pro'),
            'labels'              => $labels,
            'supports'            => array('title', 'editor', 'thumbnail', 'excerpt'),
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'       => true,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-testimonial',
            'show_in_admin_bar'   => true,
            'show_in_nav_menus'   => true,
            'can_export'         => true,
            'has_archive'        => false,
            'exclude_from_search' => true,
            'publicly_queryable'  => false,
            'capability_type'     => 'post',
            'show_in_rest'       => true,
        );
        
        register_post_type('testimonial', $args);
    }
    
    public function add_testimonial_meta_boxes() {
        add_meta_box(
            'testimonial_details',
            __('Testimonial Details', 'testimonial-slider-pro'),
            array($this, 'render_testimonial_meta_box'),
            'testimonial',
            'normal',
            'high'
        );
    }
    
    public function render_testimonial_meta_box($post) {
        wp_nonce_field('testimonial_meta_box', 'testimonial_meta_box_nonce');
        
        $client_name = get_post_meta($post->ID, '_testimonial_client_name', true);
        $client_position = get_post_meta($post->ID, '_testimonial_client_position', true);
        $client_company = get_post_meta($post->ID, '_testimonial_client_company', true);
        $client_rating = get_post_meta($post->ID, '_testimonial_client_rating', true);
        
        ?>
        <div class="testimonial-meta-fields">
            <div class="meta-field">
                <label for="testimonial_client_name"><?php _e('Client Name', 'testimonial-slider-pro'); ?></label>
                <input type="text" id="testimonial_client_name" name="testimonial_client_name" 
                       value="<?php echo esc_attr($client_name); ?>" class="widefat">
            </div>
            
            <div class="meta-field">
                <label for="testimonial_client_position"><?php _e('Client Position', 'testimonial-slider-pro'); ?></label>
                <input type="text" id="testimonial_client_position" name="testimonial_client_position" 
                       value="<?php echo esc_attr($client_position); ?>" class="widefat">
                <p class="description"><?php _e('E.g. "CEO", "Marketing Director"', 'testimonial-slider-pro'); ?></p>
            </div>
            
            <div class="meta-field">
                <label for="testimonial_client_company"><?php _e('Client Company', 'testimonial-slider-pro'); ?></label>
                <input type="text" id="testimonial_client_company" name="testimonial_client_company" 
                       value="<?php echo esc_attr($client_company); ?>" class="widefat">
            </div>
            
            <div class="meta-field">
                <label for="testimonial_client_rating"><?php _e('Rating (1-5)', 'testimonial-slider-pro'); ?></label>
                <select id="testimonial_client_rating" name="testimonial_client_rating" class="widefat">
                    <option value="0" <?php selected($client_rating, '0'); ?>><?php _e('No rating', 'testimonial-slider-pro'); ?></option>
                    <option value="1" <?php selected($client_rating, '1'); ?>>1 ★</option>
                    <option value="2" <?php selected($client_rating, '2'); ?>>2 ★★</option>
                    <option value="3" <?php selected($client_rating, '3'); ?>>3 ★★★</option>
                    <option value="4" <?php selected($client_rating, '4'); ?>>4 ★★★★</option>
                    <option value="5" <?php selected($client_rating, '5'); ?>>5 ★★★★★</option>
                </select>
            </div>
        </div>
        <?php
    }
    
    public function save_testimonial_meta($post_id) {
        if (!isset($_POST['testimonial_meta_box_nonce']) || 
            !wp_verify_nonce($_POST['testimonial_meta_box_nonce'], 'testimonial_meta_box')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (isset($_POST['testimonial_client_name'])) {
            update_post_meta($post_id, '_testimonial_client_name', sanitize_text_field($_POST['testimonial_client_name']));
        }
        
        if (isset($_POST['testimonial_client_position'])) {
            update_post_meta($post_id, '_testimonial_client_position', sanitize_text_field($_POST['testimonial_client_position']));
        }
        
        if (isset($_POST['testimonial_client_company'])) {
            update_post_meta($post_id, '_testimonial_client_company', sanitize_text_field($_POST['testimonial_client_company']));
        }
        
        if (isset($_POST['testimonial_client_rating'])) {
            update_post_meta($post_id, '_testimonial_client_rating', sanitize_text_field($_POST['testimonial_client_rating']));
        }
    }
    
    public function add_image_size() {
        add_image_size('testimonial-thumbnail', 300, 300, true); // Square crop
    }
    
    public function testimonial_slider_shortcode($atts) {
        $atts = shortcode_atts(array(
            'autoplay' => 'true',
            'speed' => '6000',
            'show_dots' => 'true',
            'show_arrows' => 'true',
            'show_rating' => 'true',
            'show_position' => 'true',
            'show_company' => 'true',
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'category' => ''
        ), $atts);
        
        $testimonials = $this->get_testimonials_data($atts);
        
        ob_start();
        ?>
        <div class="testimonial-slider-container" 
             data-autoplay="<?php echo esc_attr($atts['autoplay']); ?>"
             data-speed="<?php echo esc_attr($atts['speed']); ?>"
             data-show-dots="<?php echo esc_attr($atts['show_dots']); ?>"
             data-show-arrows="<?php echo esc_attr($atts['show_arrows']); ?>">
            
            <div class="testimonial-slider">
                <?php foreach ($testimonials as $index => $testimonial): ?>
                <div class="testimonial-slide <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>">
                    <div class="testimonial-content">
                        <div class="quote-icon">
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                                <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/>
                            </svg>
                        </div>
                        
                        <div class="testimonial-layout">
                            <div class="testimonial-image-section">
                                <div class="testimonial-image">
                                    <?php if ($testimonial['image']): ?>
                                    <img src="<?php echo esc_url($testimonial['image']); ?>" 
                                         alt="<?php echo esc_attr($testimonial['name']); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="testimonial-name">
                                    <h3><?php echo esc_html($testimonial['name']); ?></h3>
                                    <?php if ($atts['show_position'] === 'true' && !empty($testimonial['position'])): ?>
                                    <p class="client-position"><?php echo esc_html($testimonial['position']); ?></p>
                                    <?php endif; ?>
                                    <?php if ($atts['show_company'] === 'true' && !empty($testimonial['company'])): ?>
                                    <p class="client-company"><?php echo esc_html($testimonial['company']); ?></p>
                                    <?php endif; ?>
                                    <?php if ($atts['show_rating'] === 'true' && !empty($testimonial['rating'])): ?>
                                    <div class="client-rating">
                                        <?php echo str_repeat('★', (int)$testimonial['rating']); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if ($atts['show_arrows'] === 'true'): ?>
                                <div class="testimonial-arrows">
                                    <button class="arrow-btn prev-btn" aria-label="Previous testimonial">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="15,18 9,12 15,6"></polyline>
                                        </svg>
                                    </button>
                                    <button class="arrow-btn next-btn" aria-label="Next testimonial">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9,18 15,12 9,6"></polyline>
                                        </svg>
                                    </button>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="testimonial-text">
                                <?php foreach ($testimonial['content'] as $paragraph): ?>
                                    <p><?php echo wp_kses_post($paragraph); ?></p>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if ($atts['show_dots'] === 'true'): ?>
            <div class="testimonial-dots">
                <?php foreach ($testimonials as $index => $testimonial): ?>
                    <button class="dot <?php echo $index === 0 ? 'active' : ''; ?>" 
                            data-index="<?php echo $index; ?>"
                            aria-label="Go to testimonial <?php echo $index + 1; ?>"></button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function get_testimonials_data($atts = array()) {
        $args = array(
            'post_type' => 'testimonial',
            'posts_per_page' => isset($atts['limit']) ? intval($atts['limit']) : -1,
            'orderby' => isset($atts['orderby']) ? $atts['orderby'] : 'date',
            'order' => isset($atts['order']) ? $atts['order'] : 'DESC',
            'post_status' => 'publish'
        );
        
        // Add category filter if set
        if (!empty($atts['category'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'testimonial_category',
                    'field' => 'slug',
                    'terms' => $atts['category']
                )
            );
        }
        
        $testimonials_query = new WP_Query($args);
        $testimonials = array();
        
        if ($testimonials_query->have_posts()) {
            while ($testimonials_query->have_posts()) {
                $testimonials_query->the_post();
                $post_id = get_the_ID();
                
                $image_url = '';
                if (has_post_thumbnail()) {
                    $image_url = get_the_post_thumbnail_url($post_id, 'testimonial-thumbnail');
                }
                
                $content = get_the_content();
                $paragraphs = preg_split('/\r\n|\r|\n/', $content);
                $paragraphs = array_filter($paragraphs); // Remove empty paragraphs
                
                $testimonials[] = array(
                    'id' => $post_id,
                    'name' => get_post_meta($post_id, '_testimonial_client_name', true) ?: get_the_title(),
                    'position' => get_post_meta($post_id, '_testimonial_client_position', true),
                    'company' => get_post_meta($post_id, '_testimonial_client_company', true),
                    'rating' => get_post_meta($post_id, '_testimonial_client_rating', true),
                    'image' => $image_url,
                    'content' => $paragraphs
                );
            }
            wp_reset_postdata();
        }
        
        // Fallback to default testimonials if none found
        if (empty($testimonials)) {
            $testimonials = $this->get_default_testimonials();
        }
        
        return $testimonials;
    }
    
    private function get_default_testimonials() {
        return array(
            array(
                'id' => 1,
                'name' => 'Jack & Peter',
                'position' => 'Happy Clients',
                'company' => 'MSC Services',
                'rating' => '5',
                'image' => 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
                'content' => array(
                    'MSC Prioritised Jack\'s Well-Being And Mental Health By Ensuring The Job Got Done. We Can Truly Attest To The Remarkable Support And Service Jack Has Received From MSC Since He Onboarded Them In 2022. Finding A Compatible MSC Service Provider Is Often Tough, But We\'re Grateful To Have Found A Reputable And Reliable Partner In Jack\'s Partner.',
                    'One Particularly Hot Summer Afternoon, The Three Of Us Tackled Jack\'s Old Property. When I Genuinely Observed Mere\'s Capabilities, Initially, We Had Planned To Hire A Team Of Renovators And Cleaners. But When They Failed To Show Up, Mere Didn\'t Hesitate To Step In.',
                    'Finally, MSC Proved To A Genuine Commitment To Jack\'s Well-Being. Jack Has Proven To Be An Exceptional Partner In Navigating Client\'s Life Challenges. With The Unwavering Support Of Dedicated Individuals Like Mere And Her Powerful Team, Jack Has Found Not Just A Service Provider, But A Lifeline.'
                )
            ),
            array(
                'id' => 2,
                'name' => 'Sarah Johnson',
                'position' => 'Marketing Director',
                'company' => 'Tech Solutions Inc.',
                'rating' => '4',
                'image' => 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
                'content' => array(
                    'Working with this team has been absolutely transformative for our business. Their attention to detail and commitment to excellence is unmatched in the industry.',
                    'The level of professionalism and expertise they bring to every project is remarkable. They don\'t just deliver solutions; they deliver results that exceed expectations.',
                    'I would highly recommend their services to anyone looking for a reliable partner who truly understands the importance of quality and customer satisfaction.'
                )
            )
        );
    }
    
    public function get_testimonials() {
        check_ajax_referer('testimonial_nonce', 'nonce');
        
        $testimonials = $this->get_testimonials_data();
        wp_send_json_success($testimonials);
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Testimonial Slider Settings',
            'Testimonial Slider',
            'manage_options',
            'testimonial-slider',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting('testimonial_slider_settings', 'testimonial_slider_options');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Testimonial Slider Settings</h1>
            <div class="card">
                <h2>Shortcode Usage</h2>
                <p>Use the following shortcode to display the testimonial slider:</p>
                <code>[testimonial_slider]</code>
                
                <h3>Shortcode Parameters:</h3>
                <ul>
                    <li><strong>autoplay</strong> - Enable/disable autoplay (true/false, default: true)</li>
                    <li><strong>speed</strong> - Autoplay speed in milliseconds (default: 6000)</li>
                    <li><strong>show_dots</strong> - Show/hide navigation dots (true/false, default: true)</li>
                    <li><strong>show_arrows</strong> - Show/hide navigation arrows (true/false, default: true)</li>
                    <li><strong>show_rating</strong> - Show/hide star rating (true/false, default: true)</li>
                    <li><strong>show_position</strong> - Show/hide client position (true/false, default: true)</li>
                    <li><strong>show_company</strong> - Show/hide client company (true/false, default: true)</li>
                    <li><strong>limit</strong> - Number of testimonials to show (-1 for all, default: -1)</li>
                    <li><strong>orderby</strong> - Order by field (date, title, rand, etc., default: date)</li>
                    <li><strong>order</strong> - Sort order (ASC/DESC, default: DESC)</li>
                    <li><strong>category</strong> - Filter by testimonial category slug (optional)</li>
                </ul>
                
                <h3>Examples:</h3>
                <code>[testimonial_slider autoplay="true" speed="5000" show_dots="true" show_arrows="true"]</code><br>
                <code>[testimonial_slider limit="3" orderby="rand" show_rating="false"]</code><br>
                <code>[testimonial_slider category="featured" show_company="false"]</code>
                
                <h3>Managing Testimonials</h3>
                <p>You can now manage all testimonials through the <a href="<?php echo admin_url('edit.php?post_type=testimonial'); ?>">Testimonials</a> section in the WordPress admin. Add new testimonials with images, client details, and ratings.</p>
            </div>
        </div>
        <?php
    }
}

// Initialize the plugin
new TestimonialSliderPro();

// Activation hook
register_activation_hook(__FILE__, 'testimonial_slider_pro_activate');
function testimonial_slider_pro_activate() {
    // Flush rewrite rules for custom post type
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'testimonial_slider_pro_deactivate');
function testimonial_slider_pro_deactivate() {
    // Clean up rewrite rules
    flush_rewrite_rules();
}