/**
 * WordPress Image Gallery Pro JavaScript
 */

(function($) {
    'use strict';
    
    let currentGallery = [];
    let currentIndex = 0;
    let isLightboxOpen = false;
    
    $(document).ready(function() {
        initializeGalleries();
        initializeLightbox();
        bindEvents();
    });
    
    function initializeGalleries() {
        $('.wpig-gallery-container').each(function() {
            const galleryId = $(this).data('gallery-id');
            const galleryDataScript = $('#wpig-gallery-data-' + galleryId);
            
            if (galleryDataScript.length) {
                try {
                    const galleryData = JSON.parse(galleryDataScript.text());
                    $(this).data('gallery-data', galleryData);
                } catch (e) {
                    console.error('Error parsing gallery data:', e);
                }
            }
        });
    }
    
    function initializeLightbox() {
        // Create lightbox if it doesn't exist
        if ($('#wpig-lightbox').length === 0) {
            $('body').append(`
                <div class="wpig-lightbox" id="wpig-lightbox" style="display: none;">
                    <div class="wpig-lightbox-backdrop"></div>
                    <div class="wpig-lightbox-content">
                        <button class="wpig-close-btn" id="wpig-close-btn" aria-label="Close lightbox">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                        
                        <button class="wpig-prev-btn" id="wpig-prev-btn" aria-label="Previous image">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="15,18 9,12 15,6"></polyline>
                            </svg>
                        </button>
                        
                        <button class="wpig-next-btn" id="wpig-next-btn" aria-label="Next image">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="9,18 15,12 9,6"></polyline>
                            </svg>
                        </button>
                        
                        <div class="wpig-image-wrapper">
                            <img id="wpig-lightbox-image" src="" alt="" class="wpig-lightbox-image">
                        </div>
                        
                        <div class="wpig-image-info">
                            <div class="wpig-info-content">
                                <h2 id="wpig-lightbox-caption" class="wpig-lightbox-caption"></h2>
                                <p id="wpig-lightbox-description" class="wpig-lightbox-description"></p>
                                <div id="wpig-counter" class="wpig-counter"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `);
        }
    }
    
    function bindEvents() {
        // Gallery item click
        $(document).on('click', '.wpig-gallery-item', function(e) {
            e.preventDefault();
            
            const galleryContainer = $(this).closest('.wpig-gallery-container');
            const galleryData = galleryContainer.data('gallery-data');
            const imageIndex = parseInt($(this).data('index'));
            
            if (galleryData && galleryData.length > 0) {
                openLightbox(galleryData, imageIndex);
            }
        });
        
        // Lightbox controls
        $(document).on('click', '#wpig-close-btn, .wpig-lightbox-backdrop', closeLightbox);
        $(document).on('click', '#wpig-prev-btn', goToPrevious);
        $(document).on('click', '#wpig-next-btn', goToNext);
        
        // Keyboard navigation
        $(document).on('keydown', function(e) {
            if (!isLightboxOpen) return;
            
            switch (e.key) {
                case 'Escape':
                    closeLightbox();
                    break;
                case 'ArrowLeft':
                    goToPrevious();
                    break;
                case 'ArrowRight':
                    goToNext();
                    break;
            }
        });
        
        // Prevent scrolling when lightbox is open
        $(document).on('touchmove', function(e) {
            if (isLightboxOpen) {
                e.preventDefault();
            }
        });
        
        // External link clicks
        $(document).on('click', '.wpig-external-link', function(e) {
            e.stopPropagation();
        });
    }
    
    function openLightbox(galleryData, index) {
        currentGallery = galleryData;
        currentIndex = index;
        isLightboxOpen = true;
        
        updateLightboxImage();
        
        $('#wpig-lightbox').fadeIn(200);
        $('body').css('overflow', 'hidden');
        
        // Focus management for accessibility
        $('#wpig-close-btn').focus();
    }
    
    function closeLightbox() {
        isLightboxOpen = false;
        $('#wpig-lightbox').fadeOut(200);
        $('body').css('overflow', '');
        
        // Return focus to the gallery item that was clicked
        $('.wpig-gallery-item[data-index="' + currentIndex + '"]').focus();
    }
    
    function goToNext() {
        if (currentGallery.length === 0) return;
        
        currentIndex = (currentIndex + 1) % currentGallery.length;
        updateLightboxImage();
    }
    
    function goToPrevious() {
        if (currentGallery.length === 0) return;
        
        currentIndex = (currentIndex - 1 + currentGallery.length) % currentGallery.length;
        updateLightboxImage();
    }
    
    function updateLightboxImage() {
        if (!currentGallery[currentIndex]) return;
        
        const image = currentGallery[currentIndex];
        
        $('#wpig-lightbox-image').attr({
            'src': image.src,
            'alt': image.caption
        });
        
        $('#wpig-lightbox-caption').text(image.caption || '');
        $('#wpig-lightbox-description').text(image.description || '');
        $('#wpig-counter').text((currentIndex + 1) + ' of ' + currentGallery.length);
        
        // Show/hide navigation buttons
        if (currentGallery.length <= 1) {
            $('#wpig-prev-btn, #wpig-next-btn').hide();
        } else {
            $('#wpig-prev-btn, #wpig-next-btn').show();
        }
    }
    
    // Touch/swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    $(document).on('touchstart', '.wpig-lightbox-content', function(e) {
        touchStartX = e.originalEvent.changedTouches[0].screenX;
    });
    
    $(document).on('touchend', '.wpig-lightbox-content', function(e) {
        touchEndX = e.originalEvent.changedTouches[0].screenX;
        handleSwipe();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                // Swipe left - next image
                goToNext();
            } else {
                // Swipe right - previous image
                goToPrevious();
            }
        }
    }
    
    // Preload images for better performance
    function preloadImages(images, startIndex) {
        const preloadCount = 3; // Preload 3 images ahead and behind
        
        for (let i = -preloadCount; i <= preloadCount; i++) {
            const index = (startIndex + i + images.length) % images.length;
            if (images[index] && images[index].src) {
                const img = new Image();
                img.src = images[index].src;
            }
        }
    }
    
    // Image lazy loading
    function initLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('wpig-lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });
            
            $('.wpig-image.wpig-lazy').each(function() {
                imageObserver.observe(this);
            });
        }
    }
    
    // Initialize lazy loading
    initLazyLoading();
    
})(jQuery);