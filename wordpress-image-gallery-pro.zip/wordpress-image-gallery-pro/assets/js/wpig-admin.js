/**
 * WordPress Image Gallery Pro Admin JavaScript
 */

(function($) {
    'use strict';
    
    let currentGalleryId = null;
    let galleryImages = [];
    
    $(document).ready(function() {
        initializeAdmin();
        bindEvents();
    });
    
    function initializeAdmin() {
        // Tab switching
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            
            $('.nav-tab').removeClass('nav-tab-active');
            $('.wpig-tab-content').removeClass('wpig-tab-active');
            
            $(this).addClass('nav-tab-active');
            $($(this).attr('href')).addClass('wpig-tab-active');
        });
        
        // Initialize shortcode generator
        updateShortcode();
    }
    
    function bindEvents() {
        // Create new gallery
        $('#wpig-add-gallery').on('click', createNewGallery);
        
        // Edit gallery
        $(document).on('click', '.wpig-edit-gallery', function() {
            const galleryId = $(this).closest('.wpig-gallery-item').data('gallery-id');
            editGallery(galleryId);
        });
        
        // Delete gallery
        $(document).on('click', '.wpig-delete-gallery', function() {
            const galleryId = $(this).closest('.wpig-gallery-item').data('gallery-id');
            deleteGallery(galleryId);
        });
        
        // Modal close
        $('.wpig-modal-close, .wpig-modal').on('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        // Add images to gallery
        $('#wpig-add-image').on('click', openMediaUploader);
        
        // Save gallery
        $('#wpig-save-gallery').on('click', saveGallery);
        
        // Delete image from gallery
        $(document).on('click', '.wpig-delete-image', function() {
            const imageIndex = $(this).data('index');
            deleteImageFromGallery(imageIndex);
        });
        
        // Shortcode generator
        $('#wpig-shortcode-form input, #wpig-shortcode-form select').on('change', updateShortcode);
        
        // Copy shortcode
        $('#wpig-copy-shortcode').on('click', copyShortcode);
        
        // Image field updates
        $(document).on('input', '.wpig-image-field', updateImageData);
    }
    
    function createNewGallery() {
        $.post(wpig_admin_ajax.ajax_url, {
            action: 'wpig_create_gallery',
            nonce: wpig_admin_ajax.nonce
        }, function(response) {
            if (response.success) {
                showNotice(response.data.message, 'success');
                editGallery(response.data.gallery_id);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotice(response.data || wpig_admin_ajax.strings.error_occurred, 'error');
            }
        });
    }
    
    function editGallery(galleryId) {
        currentGalleryId = galleryId;
        
        // Update modal title
        $('#wpig-editor-title').text('Edit Gallery #' + galleryId);
        
        // Load gallery data
        $.post(wpig_admin_ajax.ajax_url, {
            action: 'wpig_get_gallery',
            gallery_id: galleryId,
            nonce: wpig_admin_ajax.nonce
        }, function(response) {
            if (response.success) {
                galleryImages = response.data || [];
                renderGalleryImages();
                $('#wpig-gallery-editor').show();
            } else {
                showNotice(response.data || wpig_admin_ajax.strings.error_occurred, 'error');
            }
        });
    }
    
    function deleteGallery(galleryId) {
        if (!confirm(wpig_admin_ajax.strings.confirm_delete_gallery)) {
            return;
        }
        
        $.post(wpig_admin_ajax.ajax_url, {
            action: 'wpig_delete_gallery',
            gallery_id: galleryId,
            nonce: wpig_admin_ajax.nonce
        }, function(response) {
            if (response.success) {
                showNotice(response.data, 'success');
                $('.wpig-gallery-item[data-gallery-id="' + galleryId + '"]').fadeOut(300, function() {
                    $(this).remove();
                });
            } else {
                showNotice(response.data || wpig_admin_ajax.strings.error_occurred, 'error');
            }
        });
    }
    
    function openMediaUploader() {
        const mediaUploader = wp.media({
            title: 'Select Images for Gallery',
            button: {
                text: 'Add to Gallery'
            },
            multiple: true,
            library: {
                type: 'image'
            }
        });
        
        mediaUploader.on('select', function() {
            const attachments = mediaUploader.state().get('selection').toJSON();
            
            attachments.forEach(function(attachment) {
                const imageData = {
                    src: attachment.url,
                    thumbnail: attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url,
                    caption: attachment.caption || attachment.title || '',
                    description: attachment.description || '',
                    external_link: ''
                };
                
                galleryImages.push(imageData);
            });
            
            renderGalleryImages();
        });
        
        mediaUploader.open();
    }
    
    function renderGalleryImages() {
        const container = $('#wpig-images-container');
        container.empty();
        
        if (galleryImages.length === 0) {
            container.html('<p class="wpig-no-images">No images in this gallery. Click "Add Images" to get started.</p>');
            return;
        }
        
        galleryImages.forEach(function(image, index) {
            const imageHtml = `
                <div class="wpig-image-item" data-index="${index}">
                    <div class="wpig-image-preview">
                        <img src="${image.thumbnail}" alt="${image.caption}">
                        <button type="button" class="wpig-delete-image" data-index="${index}" title="Delete Image">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </div>
                    <div class="wpig-image-fields">
                        <input type="text" class="wpig-image-field" data-field="caption" data-index="${index}" 
                               placeholder="Image Caption" value="${image.caption}">
                        <textarea class="wpig-image-field" data-field="description" data-index="${index}" 
                                  placeholder="Image Description" rows="3">${image.description}</textarea>
                        <input type="url" class="wpig-image-field" data-field="external_link" data-index="${index}" 
                               placeholder="External Link (optional)" value="${image.external_link}">
                    </div>
                </div>
            `;
            container.append(imageHtml);
        });
        
        // Make images sortable
        container.sortable({
            items: '.wpig-image-item',
            cursor: 'move',
            opacity: 0.8,
            update: function() {
                const newOrder = [];
                container.find('.wpig-image-item').each(function() {
                    const index = $(this).data('index');
                    newOrder.push(galleryImages[index]);
                });
                galleryImages = newOrder;
                renderGalleryImages(); // Re-render to update indices
            }
        });
    }
    
    function updateImageData() {
        const $field = $(this);
        const index = $field.data('index');
        const fieldName = $field.data('field');
        const value = $field.val();
        
        if (galleryImages[index]) {
            galleryImages[index][fieldName] = value;
        }
    }
    
    function deleteImageFromGallery(index) {
        if (!confirm(wpig_admin_ajax.strings.confirm_delete_image)) {
            return;
        }
        
        galleryImages.splice(index, 1);
        renderGalleryImages();
    }
    
    function saveGallery() {
        if (!currentGalleryId) {
            showNotice('No gallery selected', 'error');
            return;
        }
        
        const $saveButton = $('#wpig-save-gallery');
        $saveButton.prop('disabled', true).text('Saving...');
        
        $.post(wpig_admin_ajax.ajax_url, {
            action: 'wpig_save_gallery',
            gallery_id: currentGalleryId,
            images: JSON.stringify(galleryImages),
            nonce: wpig_admin_ajax.nonce
        }, function(response) {
            if (response.success) {
                showNotice(response.data, 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotice(response.data || wpig_admin_ajax.strings.error_occurred, 'error');
            }
        }).always(function() {
            $saveButton.prop('disabled', false).text('Save Gallery');
        });
    }
    
    function closeModal() {
        $('#wpig-gallery-editor').hide();
        currentGalleryId = null;
        galleryImages = [];
    }
    
    function updateShortcode() {
        const galleryId = $('#wpig-gallery-id').val();
        const desktopCols = $('#wpig-columns-desktop').val();
        const tabletCols = $('#wpig-columns-tablet').val();
        const mobileCols = $('#wpig-columns-mobile').val();
        const showCaptions = $('#wpig-show-captions').is(':checked') ? 'true' : 'false';
        const showDescriptions = $('#wpig-show-descriptions').is(':checked') ? 'true' : 'false';
        const showExternalLinks = $('#wpig-show-external-links').is(':checked') ? 'true' : 'false';
        
        let shortcode = `[wpig_gallery id="${galleryId}"`;
        
        if (desktopCols !== '4') shortcode += ` columns_desktop="${desktopCols}"`;
        if (tabletCols !== '3') shortcode += ` columns_tablet="${tabletCols}"`;
        if (mobileCols !== '2') shortcode += ` columns_mobile="${mobileCols}"`;
        if (showCaptions !== 'true') shortcode += ` show_captions="${showCaptions}"`;
        if (showDescriptions !== 'true') shortcode += ` show_descriptions="${showDescriptions}"`;
        if (showExternalLinks !== 'true') shortcode += ` show_external_links="${showExternalLinks}"`;
        
        shortcode += ']';
        
        $('#wpig-generated-shortcode').val(shortcode);
    }
    
    function copyShortcode() {
        const shortcode = $('#wpig-generated-shortcode');
        shortcode.select();
        document.execCommand('copy');
        
        const $button = $('#wpig-copy-shortcode');
        $button.text('Copied!').addClass('button-primary');
        setTimeout(() => {
            $button.text('Copy Shortcode').removeClass('button-primary');
        }, 2000);
    }
    
    function showNotice(message, type) {
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = `<div class="notice ${noticeClass} is-dismissible"><p>${message}</p></div>`;
        
        $('.wpig-admin-container').prepend(notice);
        
        setTimeout(() => {
            $('.notice').fadeOut();
        }, 5000);
    }
    
})(jQuery);