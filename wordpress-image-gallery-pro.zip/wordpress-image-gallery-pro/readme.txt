=== WordPress Image Gallery Pro ===
Contributors: yourname
Tags: gallery, images, lightbox, responsive, hover-effects
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A beautiful, responsive image gallery with hover effects and lightbox functionality.

== Description ==

WordPress Image Gallery Pro is a powerful and elegant image gallery plugin that creates stunning, responsive galleries with smooth hover effects and a professional lightbox modal.

**Key Features:**

* **Responsive Grid Layout**: Automatically adjusts from 4 columns on desktop to 3 on tablet and 2 on mobile
* **Hover Effects**: Beautiful overlay with eye icon, caption, description, and external link button
* **Lightbox Modal**: Full-screen image viewing with navigation arrows and close button
* **Touch-Friendly**: Optimized for mobile devices with swipe navigation
* **Keyboard Navigation**: Arrow keys for navigation, Escape to close
* **Accessibility**: Proper focus states, ARIA labels, and keyboard navigation support
* **Customizable**: Multiple display options and settings
* **Easy to Use**: Simple shortcode implementation
* **Performance Optimized**: Lazy loading and image preloading

**Perfect for:**
* Photography portfolios
* Product galleries
* Event photo collections
* Art showcases
* Real estate listings
* Travel blogs

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wordpress-image-gallery-pro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Gallery Pro menu item to create and manage your galleries
4. Add galleries to your posts/pages using the shortcode: `[wpig_gallery id="1"]`

== Frequently Asked Questions ==

= How do I create a new gallery? =

Go to Gallery Pro in your WordPress admin menu, click "Create New Gallery", add your images, and save. You'll get a shortcode to use in your posts or pages.

= Can I customize the number of columns? =

Yes! You can set different column numbers for desktop, tablet, and mobile devices using shortcode attributes:
`[wpig_gallery id="1" columns_desktop="4" columns_tablet="3" columns_mobile="2"]`

= How do I add external links to images? =

When editing a gallery, each image has an "External Link" field where you can add a URL. This will show as a button in the hover overlay.

= Is the gallery responsive? =

Absolutely! The gallery automatically adapts to different screen sizes with customizable column layouts for desktop, tablet, and mobile devices.

= Can I disable certain features? =

Yes, you can control what shows in the hover overlay:
`[wpig_gallery id="1" show_captions="false" show_descriptions="false" show_external_links="false"]`

== Screenshots ==

1. Gallery grid view with hover effects
2. Lightbox modal with navigation
3. Admin gallery manager
4. Shortcode generator
5. Mobile responsive design

== Changelog ==

= 1.0.0 =
* Initial release
* Responsive grid layout
* Hover effects with overlay
* Lightbox modal functionality
* Touch and keyboard navigation
* Admin interface for gallery management
* Shortcode generator
* Accessibility features

== Upgrade Notice ==

= 1.0.0 =
Initial release of WordPress Image Gallery Pro.

== Shortcode Attributes ==

* `id` - Gallery ID (required)
* `columns_desktop` - Number of columns on desktop (default: 4)
* `columns_tablet` - Number of columns on tablet (default: 3)
* `columns_mobile` - Number of columns on mobile (default: 2)
* `show_captions` - Show image captions (default: true)
* `show_descriptions` - Show image descriptions (default: true)
* `show_external_links` - Show external link buttons (default: true)

**Example:**
`[wpig_gallery id="1" columns_desktop="3" columns_tablet="2" columns_mobile="1" show_captions="true"]`

== Support ==

For support and feature requests, please visit our website or contact us through the WordPress support forums.