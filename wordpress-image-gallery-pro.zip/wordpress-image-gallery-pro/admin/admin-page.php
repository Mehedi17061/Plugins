<div class="wrap">
    <h1><?php _e('Image Gallery Pro', 'wpig-pro'); ?></h1>
    
    <div class="wpig-admin-container">
        <div class="wpig-admin-header">
            <h2><?php _e('Manage Your Image Galleries', 'wpig-pro'); ?></h2>
            <p><?php _e('Create and manage beautiful image galleries with hover effects and lightbox functionality.', 'wpig-pro'); ?></p>
        </div>
        
        <div class="wpig-admin-tabs">
            <nav class="nav-tab-wrapper">
                <a href="#gallery-manager" class="nav-tab nav-tab-active"><?php _e('Gallery Manager', 'wpig-pro'); ?></a>
                <a href="#shortcode-generator" class="nav-tab"><?php _e('Shortcode Generator', 'wpig-pro'); ?></a>
                <a href="#settings" class="nav-tab"><?php _e('Settings', 'wpig-pro'); ?></a>
            </nav>
            
            <div id="gallery-manager" class="wpig-tab-content wpig-tab-active">
                <div class="wpig-gallery-manager">
                    <div class="wpig-manager-header">
                        <h3><?php _e('Gallery Manager', 'wpig-pro'); ?></h3>
                        <button type="button" class="button button-primary" id="wpig-add-gallery">
                            <?php _e('Create New Gallery', 'wpig-pro'); ?>
                        </button>
                    </div>
                    
                    <div class="wpig-galleries-list">
                        <?php if (empty($galleries)): ?>
                            <div class="wpig-no-galleries">
                                <p><?php _e('No galleries found. Create your first gallery to get started!', 'wpig-pro'); ?></p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($galleries as $gallery_id => $gallery_data): ?>
                                <div class="wpig-gallery-item" data-gallery-id="<?php echo esc_attr($gallery_id); ?>">
                                    <div class="wpig-gallery-header">
                                        <h4><?php printf(__('Gallery #%s', 'wpig-pro'), $gallery_id); ?></h4>
                                        <div class="wpig-gallery-actions">
                                            <button type="button" class="button wpig-edit-gallery"><?php _e('Edit', 'wpig-pro'); ?></button>
                                            <button type="button" class="button wpig-delete-gallery"><?php _e('Delete', 'wpig-pro'); ?></button>
                                        </div>
                                    </div>
                                    <div class="wpig-gallery-info">
                                        <p><?php printf(__('%d images', 'wpig-pro'), count($gallery_data)); ?></p>
                                        <code>[wpig_gallery id="<?php echo esc_attr($gallery_id); ?>"]</code>
                                    </div>
                                    <div class="wpig-gallery-preview">
                                        <?php if (!empty($gallery_data)): ?>
                                            <?php foreach (array_slice($gallery_data, 0, 4) as $image): ?>
                                                <img src="<?php echo esc_url($image['thumbnail']); ?>" alt="<?php echo esc_attr($image['caption']); ?>" class="wpig-preview-thumb">
                                            <?php endforeach; ?>
                                            <?php if (count($gallery_data) > 4): ?>
                                                <div class="wpig-more-images">+<?php echo count($gallery_data) - 4; ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div id="shortcode-generator" class="wpig-tab-content">
                <div class="wpig-shortcode-generator">
                    <h3><?php _e('Shortcode Generator', 'wpig-pro'); ?></h3>
                    <p><?php _e('Customize your gallery display options and generate the shortcode.', 'wpig-pro'); ?></p>
                    
                    <?php if (!empty($galleries)): ?>
                        <form id="wpig-shortcode-form">
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Gallery ID', 'wpig-pro'); ?></th>
                                    <td>
                                        <select name="gallery_id" id="wpig-gallery-id">
                                            <?php foreach ($galleries as $gallery_id => $gallery_data): ?>
                                                <option value="<?php echo esc_attr($gallery_id); ?>">
                                                    <?php printf(__('Gallery #%s (%d images)', 'wpig-pro'), $gallery_id, count($gallery_data)); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Desktop Columns', 'wpig-pro'); ?></th>
                                    <td>
                                        <select name="columns_desktop" id="wpig-columns-desktop">
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4" selected>4</option>
                                            <option value="5">5</option>
                                            <option value="6">6</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Tablet Columns', 'wpig-pro'); ?></th>
                                    <td>
                                        <select name="columns_tablet" id="wpig-columns-tablet">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3" selected>3</option>
                                            <option value="4">4</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Mobile Columns', 'wpig-pro'); ?></th>
                                    <td>
                                        <select name="columns_mobile" id="wpig-columns-mobile">
                                            <option value="1">1</option>
                                            <option value="2" selected>2</option>
                                            <option value="3">3</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Show Captions', 'wpig-pro'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="show_captions" id="wpig-show-captions" checked>
                                            <?php _e('Display image captions on hover', 'wpig-pro'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Show Descriptions', 'wpig-pro'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="show_descriptions" id="wpig-show-descriptions" checked>
                                            <?php _e('Display image descriptions on hover', 'wpig-pro'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Show External Links', 'wpig-pro'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="show_external_links" id="wpig-show-external-links" checked>
                                            <?php _e('Display external link buttons on hover', 'wpig-pro'); ?>
                                        </label>
                                    </td>
                                </tr>
                            </table>
                            
                            <div class="wpig-shortcode-output">
                                <h4><?php _e('Generated Shortcode:', 'wpig-pro'); ?></h4>
                                <input type="text" id="wpig-generated-shortcode" class="large-text code" readonly>
                                <button type="button" class="button" id="wpig-copy-shortcode"><?php _e('Copy Shortcode', 'wpig-pro'); ?></button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="wpig-no-galleries">
                            <p><?php _e('No galleries available. Please create a gallery first.', 'wpig-pro'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div id="settings" class="wpig-tab-content">
                <div class="wpig-settings">
                    <h3><?php _e('Plugin Settings', 'wpig-pro'); ?></h3>
                    
                    <form method="post" action="options.php">
                        <?php settings_fields('wpig_settings'); ?>
                        <?php do_settings_sections('wpig_settings'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row"><?php _e('Default Animation Speed', 'wpig-pro'); ?></th>
                                <td>
                                    <select name="wpig_animation_speed">
                                        <option value="fast"><?php _e('Fast (200ms)', 'wpig-pro'); ?></option>
                                        <option value="normal" selected><?php _e('Normal (300ms)', 'wpig-pro'); ?></option>
                                        <option value="slow"><?php _e('Slow (500ms)', 'wpig-pro'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Lightbox Background', 'wpig-pro'); ?></th>
                                <td>
                                    <select name="wpig_lightbox_bg">
                                        <option value="dark" selected><?php _e('Dark', 'wpig-pro'); ?></option>
                                        <option value="light"><?php _e('Light', 'wpig-pro'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><?php _e('Enable Lazy Loading', 'wpig-pro'); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="wpig_lazy_loading" checked>
                                        <?php _e('Enable lazy loading for better performance', 'wpig-pro'); ?>
                                    </label>
                                </td>
                            </tr>
                        </table>
                        
                        <?php submit_button(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Gallery Editor Modal -->
<div id="wpig-gallery-editor" class="wpig-modal" style="display: none;">
    <div class="wpig-modal-content">
        <div class="wpig-modal-header">
            <h3 id="wpig-editor-title"><?php _e('Edit Gallery', 'wpig-pro'); ?></h3>
            <button type="button" class="wpig-modal-close">&times;</button>
        </div>
        <div class="wpig-modal-body">
            <div class="wpig-editor-toolbar">
                <button type="button" class="button button-primary" id="wpig-add-image">
                    <?php _e('Add Images', 'wpig-pro'); ?>
                </button>
                <button type="button" class="button button-secondary" id="wpig-save-gallery">
                    <?php _e('Save Gallery', 'wpig-pro'); ?>
                </button>
            </div>
            <div id="wpig-images-container" class="wpig-images-grid">
                <!-- Images will be loaded here -->
            </div>
        </div>
    </div>
</div>