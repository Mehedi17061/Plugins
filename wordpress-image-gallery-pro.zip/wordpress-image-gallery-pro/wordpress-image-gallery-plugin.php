<?php
/**
 * Plugin Name: WordPress Image Gallery Pro
 * Plugin URI: https://example.com/wordpress-image-gallery-pro
 * Description: A beautiful, responsive image gallery with hover effects and lightbox functionality. Supports 4 columns on desktop, 3 on tablet, and 2 on mobile.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wpig-pro
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WPIG_PRO_VERSION', '1.0.0');
define('WPIG_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPIG_PRO_PLUGIN_PATH', plugin_dir_path(__FILE__));

class WPImageGalleryPro {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_shortcode('wpig_gallery', array($this, 'gallery_shortcode'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // AJAX actions
        add_action('wp_ajax_wpig_save_gallery', array($this, 'ajax_save_gallery'));
        add_action('wp_ajax_wpig_delete_gallery', array($this, 'ajax_delete_gallery'));
        add_action('wp_ajax_wpig_get_gallery', array($this, 'ajax_get_gallery'));
        add_action('wp_ajax_wpig_create_gallery', array($this, 'ajax_create_gallery'));
        
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        load_plugin_textdomain('wpig-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('wpig-pro-style', WPIG_PRO_PLUGIN_URL . 'assets/css/wpig-style.css', array(), WPIG_PRO_VERSION);
        wp_enqueue_script('wpig-pro-script', WPIG_PRO_PLUGIN_URL . 'assets/js/wpig-script.js', array('jquery'), WPIG_PRO_VERSION, true);
        
        wp_localize_script('wpig-pro-script', 'wpig_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpig_nonce')
        ));
    }
    
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_wpig-pro') {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_style('wpig-admin-style', WPIG_PRO_PLUGIN_URL . 'assets/css/wpig-admin.css', array(), WPIG_PRO_VERSION);
        wp_enqueue_script('wpig-admin-script', WPIG_PRO_PLUGIN_URL . 'assets/js/wpig-admin.js', array('jquery', 'media-upload', 'media-views'), WPIG_PRO_VERSION, true);
        
        wp_localize_script('wpig-admin-script', 'wpig_admin_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpig_admin_nonce'),
            'strings' => array(
                'confirm_delete_gallery' => __('Are you sure you want to delete this gallery?', 'wpig-pro'),
                'confirm_delete_image' => __('Are you sure you want to delete this image?', 'wpig-pro'),
                'gallery_saved' => __('Gallery saved successfully!', 'wpig-pro'),
                'gallery_deleted' => __('Gallery deleted successfully!', 'wpig-pro'),
                'error_occurred' => __('An error occurred. Please try again.', 'wpig-pro')
            )
        ));
    }
    
    public function gallery_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 1,
            'columns_desktop' => 4,
            'columns_tablet' => 3,
            'columns_mobile' => 2,
            'show_captions' => 'true',
            'show_descriptions' => 'true',
            'show_external_links' => 'true'
        ), $atts);
        
        $gallery_data = get_option('wpig_gallery_' . $atts['id'], array());
        
        if (empty($gallery_data)) {
            return '<p>' . __('No images found in this gallery.', 'wpig-pro') . '</p>';
        }
        
        ob_start();
        ?>
        <div class="wpig-gallery-container" data-gallery-id="<?php echo esc_attr($atts['id']); ?>">
            <div class="wpig-gallery-grid wpig-cols-desktop-<?php echo esc_attr($atts['columns_desktop']); ?> wpig-cols-tablet-<?php echo esc_attr($atts['columns_tablet']); ?> wpig-cols-mobile-<?php echo esc_attr($atts['columns_mobile']); ?>">
                <?php foreach ($gallery_data as $index => $image): ?>
                    <div class="wpig-gallery-item" data-index="<?php echo esc_attr($index); ?>">
                        <div class="wpig-image-container">
                            <img src="<?php echo esc_url($image['thumbnail']); ?>" 
                                 alt="<?php echo esc_attr($image['caption']); ?>" 
                                 class="wpig-image" 
                                 loading="lazy">
                            
                            <div class="wpig-overlay">
                                <div class="wpig-overlay-content">
                                    <div class="wpig-view-icon">
                                        <svg class="wpig-eye-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                            <circle cx="12" cy="12" r="3"></circle>
                                        </svg>
                                    </div>
                                    
                                    <?php if ($atts['show_captions'] === 'true' && !empty($image['caption'])): ?>
                                        <h3 class="wpig-caption"><?php echo esc_html($image['caption']); ?></h3>
                                    <?php endif; ?>
                                    
                                    <?php if ($atts['show_descriptions'] === 'true' && !empty($image['description'])): ?>
                                        <p class="wpig-description"><?php echo esc_html($image['description']); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if ($atts['show_external_links'] === 'true' && !empty($image['external_link'])): ?>
                                        <a href="<?php echo esc_url($image['external_link']); ?>" 
                                           target="_blank" 
                                           rel="noopener noreferrer" 
                                           class="wpig-external-link"
                                           onclick="event.stopPropagation();">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                                <polyline points="15,3 21,3 21,9"></polyline>
                                                <line x1="10" y1="14" x2="21" y2="3"></line>
                                            </svg>
                                            <?php _e('Visit Link', 'wpig-pro'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <script type="application/json" id="wpig-gallery-data-<?php echo esc_attr($atts['id']); ?>">
            <?php echo wp_json_encode($gallery_data); ?>
        </script>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('Image Gallery Pro', 'wpig-pro'),
            __('Gallery Pro', 'wpig-pro'),
            'manage_options',
            'wpig-pro',
            array($this, 'admin_page'),
            'dashicons-format-gallery',
            30
        );
    }
    
    public function admin_page() {
        $galleries = $this->get_all_galleries();
        include WPIG_PRO_PLUGIN_PATH . 'admin/admin-page.php';
    }
    
    // AJAX: Create new gallery
    public function ajax_create_gallery() {
        check_ajax_referer('wpig_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'wpig-pro'));
        }
        
        $galleries = $this->get_all_galleries();
        $new_id = empty($galleries) ? 1 : max(array_keys($galleries)) + 1;
        
        update_option('wpig_gallery_' . $new_id, array());
        
        wp_send_json_success(array(
            'gallery_id' => $new_id,
            'message' => __('New gallery created successfully!', 'wpig-pro')
        ));
    }
    
    // AJAX: Save gallery
    public function ajax_save_gallery() {
        check_ajax_referer('wpig_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'wpig-pro'));
        }
        
        $gallery_id = intval($_POST['gallery_id']);
        $images = isset($_POST['images']) ? json_decode(stripslashes($_POST['images']), true) : array();
        
        if (!$gallery_id) {
            wp_send_json_error(__('Invalid gallery ID.', 'wpig-pro'));
        }
        
        // Sanitize image data
        $sanitized_images = array();
        if (is_array($images)) {
            foreach ($images as $image) {
                $sanitized_images[] = array(
                    'src' => esc_url_raw($image['src']),
                    'thumbnail' => esc_url_raw($image['thumbnail']),
                    'caption' => sanitize_text_field($image['caption']),
                    'description' => sanitize_textarea_field($image['description']),
                    'external_link' => esc_url_raw($image['external_link'])
                );
            }
        }
        
        update_option('wpig_gallery_' . $gallery_id, $sanitized_images);
        
        wp_send_json_success(__('Gallery saved successfully!', 'wpig-pro'));
    }
    
    // AJAX: Delete gallery
    public function ajax_delete_gallery() {
        check_ajax_referer('wpig_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'wpig-pro'));
        }
        
        $gallery_id = intval($_POST['gallery_id']);
        
        if (!$gallery_id) {
            wp_send_json_error(__('Invalid gallery ID.', 'wpig-pro'));
        }
        
        delete_option('wpig_gallery_' . $gallery_id);
        
        wp_send_json_success(__('Gallery deleted successfully!', 'wpig-pro'));
    }
    
    // AJAX: Get gallery data
    public function ajax_get_gallery() {
        check_ajax_referer('wpig_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'wpig-pro'));
        }
        
        $gallery_id = intval($_POST['gallery_id']);
        
        if (!$gallery_id) {
            wp_send_json_error(__('Invalid gallery ID.', 'wpig-pro'));
        }
        
        $gallery_data = get_option('wpig_gallery_' . $gallery_id, array());
        
        wp_send_json_success($gallery_data);
    }
    
    private function get_all_galleries() {
        global $wpdb;
        $results = $wpdb->get_results(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'wpig_gallery_%'",
            ARRAY_A
        );
        
        $galleries = array();
        foreach ($results as $result) {
            $gallery_id = str_replace('wpig_gallery_', '', $result['option_name']);
            if (is_numeric($gallery_id)) {
                $galleries[$gallery_id] = get_option($result['option_name'], array());
            }
        }
        
        return $galleries;
    }
    
    public function activate() {
        // Create default gallery
        $default_images = array(
            array(
                'src' => 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=800',
                'thumbnail' => 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=400',
                'caption' => 'Mountain Landscape',
                'description' => 'Breathtaking view of snow-capped mountains under a clear blue sky',
                'external_link' => 'https://example.com/mountain-adventure'
            ),
            array(
                'src' => 'https://images.pexels.com/photos/346529/pexels-photo-346529.jpeg?auto=compress&cs=tinysrgb&w=800',
                'thumbnail' => 'https://images.pexels.com/photos/346529/pexels-photo-346529.jpeg?auto=compress&cs=tinysrgb&w=400',
                'caption' => 'Ocean Waves',
                'description' => 'Powerful ocean waves crashing against rocky shores',
                'external_link' => 'https://example.com/ocean-photography'
            ),
            array(
                'src' => 'https://images.pexels.com/photos/443446/pexels-photo-443446.jpeg?auto=compress&cs=tinysrgb&w=800',
                'thumbnail' => 'https://images.pexels.com/photos/443446/pexels-photo-443446.jpeg?auto=compress&cs=tinysrgb&w=400',
                'caption' => 'Forest Path',
                'description' => 'A serene walking path through lush green forest',
                'external_link' => 'https://example.com/forest-hiking'
            ),
            array(
                'src' => 'https://images.pexels.com/photos/158251/forest-the-sun-morning-tucholskie-158251.jpeg?auto=compress&cs=tinysrgb&w=800',
                'thumbnail' => 'https://images.pexels.com/photos/158251/forest-the-sun-morning-tucholskie-158251.jpeg?auto=compress&cs=tinysrgb&w=400',
                'caption' => 'Sunrise Forest',
                'description' => 'Golden sunrise filtering through misty forest trees',
                'external_link' => 'https://example.com/sunrise-photography'
            )
        );
        
        update_option('wpig_gallery_1', $default_images);
    }
    
    public function deactivate() {
        // Clean up if needed
    }
}

// Initialize the plugin
new WPImageGalleryPro();
?>