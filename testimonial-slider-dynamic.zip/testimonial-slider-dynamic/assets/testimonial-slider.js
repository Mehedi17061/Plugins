
document.addEventListener("DOMContentLoaded", function () {
    const slider = document.querySelector('.testimonial-slider');
    const slides = document.querySelectorAll('.testimonial-slide');
    const next = document.querySelectorAll('.next-btn');
    const prev = document.querySelectorAll('.prev-btn');
    let index = 0;

    function showSlide(i) {
        if (i >= slides.length) index = 0;
        if (i < 0) index = slides.length - 1;
        slider.style.transform = `translateX(-${index * 100}%)`;
    }

    next.forEach(btn => btn.addEventListener('click', () => {
        index++;
        showSlide(index);
    }));

    prev.forEach(btn => btn.addEventListener('click', () => {
        index--;
        showSlide(index);
    }));
});
