<?php
/*
Plugin Name: Testimonial Slider Dynamic
Plugin URI: https://yourwebsite.com/testimonial-slider
Description: A beautiful testimonial slider with dynamic custom post type support and responsive design.
Version: 1.1.0
Author: Your Name
Author URI: https://yourwebsite.com
License: GPL v2 or later
Text Domain: testimonial-slider
*/

if (!defined('ABSPATH')) {
    exit;
}

class TestimonialSliderDynamic {

    public function __construct() {
        add_action('init', array($this, 'register_testimonial_post_type'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('testimonial_slider', array($this, 'testimonial_slider_shortcode'));
    }

    public function register_testimonial_post_type() {
        $labels = array(
            'name' => 'Testimonials',
            'singular_name' => 'Testimonial',
            'menu_name' => 'Testimonials',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Testimonial',
            'edit_item' => 'Edit Testimonial',
            'new_item' => 'New Testimonial',
            'view_item' => 'View Testimonial',
            'search_items' => 'Search Testimonials',
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-format-quote',
        );

        register_post_type('testimonial', $args);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('testimonial-slider-css', plugin_dir_url(__FILE__) . 'assets/testimonial-slider.css');
        wp_enqueue_script('testimonial-slider-js', plugin_dir_url(__FILE__) . 'assets/testimonial-slider.js', array('jquery'), '1.0', true);
    }

    public function testimonial_slider_shortcode($atts) {
        $args = array('post_type' => 'testimonial', 'posts_per_page' => -1);
        $query = new WP_Query($args);

        ob_start();

        if ($query->have_posts()) :
        ?>
        <div class="testimonial-slider-container">
            <div class="testimonial-slider">
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <div class="testimonial-slide">
                        <div class="testimonial-content">
                            <div class="quote-icon">“</div>
                            <div class="testimonial-layout">
                                <div class="testimonial-image-section">
                                    <div class="testimonial-image">
                                        <?php if (has_post_thumbnail()) the_post_thumbnail('medium'); ?>
                                    </div>
                                    <div class="testimonial-name">
                                        <h3><?php the_title(); ?></h3>
                                    </div>
                                    <div class="testimonial-arrows">
                                        <button class="arrow-btn prev-btn">‹</button>
                                        <button class="arrow-btn next-btn">›</button>
                                    </div>
                                </div>
                                <div class="testimonial-text">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php
        endif;
        wp_reset_postdata();

        return ob_get_clean();
    }
}

new TestimonialSliderDynamic();
?>
