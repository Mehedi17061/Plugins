=== Responsive Image Gallery Pro ===
Contributors: yourname
Tags: gallery, responsive, images, hover effects, mobile-friendly, dynamic
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A professional, responsive image gallery with hover effects, dynamic image management, and unique CSS classes. Shows 4 images on desktop, 3 on tablet, and 2 on mobile.

== Description ==

Responsive Image Gallery Pro is a premium WordPress plugin that creates beautiful, responsive image galleries with smooth hover effects and professional design. Perfect for showcasing portfolios, products, or any collection of images with complete dynamic management.

**Key Features:**

* **Unique CSS Classes**: All classes prefixed with `rigp-` to avoid conflicts
* **Dynamic Image Management**: Add, edit, delete, and reorder images via AJAX
* **Responsive Design**: 4 columns on desktop, 3 on tablet, 2 on mobile
* **Professional Hover Effects**: Smooth overlay with captions and external links
* **Link Button Icon**: Positioned above captions for better UX
* **WordPress Media Integration**: Built-in media uploader support
* **Drag & Drop Reordering**: Intuitive image management
* **Touch-Friendly**: Optimized for mobile and touch devices
* **Performance Optimized**: Lazy loading and efficient code
* **SEO Friendly**: Proper alt tags and semantic HTML
* **Accessibility**: Keyboard navigation and screen reader support

**Perfect For:**
* Photography portfolios
* Product showcases
* Travel galleries
* Art collections
* Business showcases
* Any visual content display

**Technical Features:**
* AJAX-powered admin interface
* Unique database table with prefix
* WordPress media library integration
* Sortable gallery management
* Form validation and error handling
* Responsive CSS Grid layout
* Modern JavaScript (ES6+)
* Performance monitoring
* Analytics integration ready

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/responsive-image-gallery/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to 'RIGP Gallery' in your WordPress admin menu
4. Add images using the dynamic form or media uploader
5. Use the shortcode `[rigp_gallery]` in any post, page, or widget

== Usage ==

**Basic Usage:**
```
[rigp_gallery]
```

**With Parameters:**
```
[rigp_gallery limit="8"]
[rigp_gallery orderby="caption" order="DESC"]
[rigp_gallery limit="12" orderby="sort_order" order="ASC"]
[rigp_gallery class="custom-gallery"]
```

**Available Parameters:**
* `limit` - Number of images to display (default: all)
* `orderby` - Sort by: sort_order, caption, created_at (default: sort_order)
* `order` - ASC or DESC (default: ASC)
* `class` - Add custom CSS class to gallery container

**Admin Features:**
* **Add Images**: Dynamic form with media uploader integration
* **Edit Images**: Click edit button to modify any image
* **Delete Images**: One-click deletion with confirmation
* **Reorder Images**: Drag and drop to change order
* **Bulk Management**: Efficient handling of multiple images

== Frequently Asked Questions ==

= How do I add images to the gallery? =

Go to 'RIGP Gallery' in your WordPress admin, use the dynamic form to add images, or click the "Upload" button to use the WordPress media library.

= Can I customize the appearance? =

Yes! All CSS classes are prefixed with `rigp-` and can be overridden in your theme. Main classes include `.rigp-gallery-grid`, `.rigp-gallery-item`, and `.rigp-overlay`.

= Is it mobile-friendly? =

Absolutely! The gallery is fully responsive with touch-friendly interactions and optimized for all devices.

= Can I reorder images? =

Yes, simply drag and drop images in the admin interface to reorder them.

= How do I edit existing images? =

Click the edit button (pencil icon) on any image in the admin interface to open the edit modal.

= Can I use multiple galleries? =

Yes, you can use the shortcode multiple times with different parameters on the same page.

== Screenshots ==

1. Gallery display on desktop (4 columns)
2. Gallery display on tablet (3 columns)
3. Gallery display on mobile (2 columns)
4. Hover effect with link button above caption
5. Dynamic admin interface with drag & drop
6. Edit modal for updating images
7. Media uploader integration

== Changelog ==

= 1.0.0 =
* Initial release
* Unique CSS classes with `rigp-` prefix
* Dynamic image management with AJAX
* Responsive grid layout (4/3/2 columns)
* Professional hover effects
* Link button positioned above captions
* WordPress media library integration
* Drag & drop reordering
* Edit/delete functionality
* Touch and keyboard accessibility
* Performance optimizations
* SEO and accessibility features

== Upgrade Notice ==

= 1.0.0 =
Initial release of Responsive Image Gallery Pro with dynamic management and unique classes.

== Technical Specifications ==

**Database:**
* Custom table: `wp_rigp_gallery_images`
* Unique prefix to avoid conflicts
* Optimized indexes for performance

**CSS Classes:**
* All classes prefixed with `rigp-`
* No conflicts with themes or other plugins
* Modular and maintainable structure

**JavaScript:**
* Modern ES6+ features
* AJAX-powered admin interface
* Performance monitoring
* Touch and keyboard support

**Browser Support:**
* Chrome 60+
* Firefox 55+
* Safari 12+
* Edge 79+
* iOS Safari 12+
* Android Chrome 60+

**Performance Features:**
* Lazy loading for images
* CSS Grid for efficient layouts
* Optimized hover animations
* Minimal JavaScript footprint
* Database query optimization

**Security Features:**
* Nonce verification for all AJAX requests
* Capability checks for admin functions
* Input sanitization and validation
* SQL injection prevention

== Support ==

For support, feature requests, or bug reports, please use the plugin support forum or contact us through our website.

== Credits ==

Developed with modern web standards, WordPress best practices, and attention to performance and accessibility.