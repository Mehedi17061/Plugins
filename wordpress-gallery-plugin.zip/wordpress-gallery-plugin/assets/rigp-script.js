jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize gallery functionality
    initializeRIGPGallery();
    
    function initializeRIGPGallery() {
        // Handle touch events for mobile
        if ('ontouchstart' in window) {
            handleRIGPTouchEvents();
        }
        
        // Handle keyboard navigation
        handleRIGPKeyboardNavigation();
        
        // Lazy loading optimization
        handleRIGPLazyLoading();
        
        // Analytics tracking
        handleRIGPAnalytics();
        
        // Responsive behavior
        handleRIGPResponsiveUpdates();
    }
    
    function handleRIGPTouchEvents() {
        $('.rigp-gallery-item').on('touchstart', function(e) {
            $(this).addClass('rigp-touch-active');
        });
        
        $('.rigp-gallery-item').on('touchend', function(e) {
            var $this = $(this);
            setTimeout(function() {
                $this.removeClass('rigp-touch-active');
            }, 300);
        });
        
        // Handle touch for external links
        $('.rigp-link-btn').on('touchend', function(e) {
            e.stopPropagation();
        });
    }
    
    function handleRIGPKeyboardNavigation() {
        $('.rigp-gallery-item').attr('tabindex', '0');
        
        $('.rigp-gallery-item').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                var $linkBtn = $(this).find('.rigp-link-btn');
                if ($linkBtn.length) {
                    $linkBtn[0].click();
                }
            }
        });
        
        $('.rigp-link-btn').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.stopPropagation();
            }
        });
    }
    
    function handleRIGPLazyLoading() {
        if ('IntersectionObserver' in window) {
            var imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            img.classList.remove('rigp-lazy');
                            imageObserver.unobserve(img);
                        }
                    }
                });
            });
            
            $('.rigp-gallery-image.rigp-lazy').each(function() {
                imageObserver.observe(this);
            });
        }
    }
    
    function handleRIGPAnalytics() {
        // Track external link clicks
        $('.rigp-link-btn').on('click', function(e) {
            var href = $(this).attr('href');
            var caption = $(this).closest('.rigp-gallery-item').find('.rigp-caption').text();
            
            // Google Analytics 4 event tracking
            if (typeof gtag !== 'undefined') {
                gtag('event', 'rigp_link_click', {
                    'link_url': href,
                    'image_caption': caption,
                    'event_category': 'RIGP Gallery',
                    'event_label': caption
                });
            }
            
            // Universal Analytics fallback
            if (typeof ga !== 'undefined') {
                ga('send', 'event', 'RIGP Gallery', 'External Link Click', caption);
            }
        });
        
        // Track gallery interactions
        $('.rigp-gallery-item').on('mouseenter', function() {
            var caption = $(this).find('.rigp-caption').text();
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'rigp_hover', {
                    'image_caption': caption,
                    'event_category': 'RIGP Gallery',
                    'event_label': 'Image Hover'
                });
            }
        });
    }
    
    function handleRIGPResponsiveUpdates() {
        var $gallery = $('.rigp-gallery-grid');
        var windowWidth = $(window).width();
        
        $gallery.removeClass('rigp-mobile rigp-tablet rigp-desktop');
        
        if (windowWidth < 768) {
            $gallery.addClass('rigp-mobile');
        } else if (windowWidth < 1024) {
            $gallery.addClass('rigp-tablet');
        } else {
            $gallery.addClass('rigp-desktop');
        }
    }
    
    // Update on window resize
    $(window).on('resize', rigpDebounce(handleRIGPResponsiveUpdates, 250));
    
    // Handle image loading errors
    $('.rigp-gallery-image').on('error', function() {
        $(this).attr('src', 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIG5vdCBmb3VuZDwvdGV4dD48L3N2Zz4=');
        $(this).closest('.rigp-gallery-item').addClass('rigp-image-error');
    });
    
    // Preload images on hover
    $('.rigp-gallery-item').on('mouseenter', function() {
        var $img = $(this).find('.rigp-gallery-image');
        var src = $img.attr('src');
        
        if (src && !$img.data('rigp-preloaded')) {
            var preloadImg = new Image();
            preloadImg.src = src;
            $img.data('rigp-preloaded', true);
        }
    });
    
    // Utility function for debouncing
    function rigpDebounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
    
    // Performance monitoring
    if (window.performance && window.performance.mark) {
        window.performance.mark('rigp-gallery-init-start');
        
        $(window).on('load', function() {
            window.performance.mark('rigp-gallery-init-end');
            window.performance.measure('rigp-gallery-init', 'rigp-gallery-init-start', 'rigp-gallery-init-end');
        });
    }
});