jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize gallery functionality
    initializeGallery();
    
    function initializeGallery() {
        // Handle touch events for mobile
        if ('ontouchstart' in window) {
            handleTouchEvents();
        }
        
        // Handle keyboard navigation
        handleKeyboardNavigation();
        
        // Lazy loading optimization
        handleLazyLoading();
        
        // Analytics tracking (if needed)
        handleAnalytics();
    }
    
    function handleTouchEvents() {
        $('.gallery-item').on('touchstart', function(e) {
            $(this).addClass('touch-active');
        });
        
        $('.gallery-item').on('touchend', function(e) {
            var $this = $(this);
            setTimeout(function() {
                $this.removeClass('touch-active');
            }, 300);
        });
        
        // Handle touch for external links
        $('.gallery-link-btn').on('touchend', function(e) {
            e.stopPropagation();
            // Link will naturally follow href
        });
    }
    
    function handleKeyboardNavigation() {
        $('.gallery-item').attr('tabindex', '0');
        
        $('.gallery-item').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                var $linkBtn = $(this).find('.gallery-link-btn');
                if ($linkBtn.length) {
                    $linkBtn[0].click();
                }
            }
        });
        
        $('.gallery-link-btn').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.stopPropagation();
                // Let the default behavior handle the link
            }
        });
    }
    
    function handleLazyLoading() {
        // Intersection Observer for better performance
        if ('IntersectionObserver' in window) {
            var imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            img.classList.remove('lazy');
                            imageObserver.unobserve(img);
                        }
                    }
                });
            });
            
            $('.gallery-image.lazy').each(function() {
                imageObserver.observe(this);
            });
        }
    }
    
    function handleAnalytics() {
        // Track external link clicks
        $('.gallery-link-btn').on('click', function(e) {
            var href = $(this).attr('href');
            var caption = $(this).closest('.gallery-item').find('.gallery-caption').text();
            
            // Google Analytics 4 event tracking (if GA is loaded)
            if (typeof gtag !== 'undefined') {
                gtag('event', 'gallery_link_click', {
                    'link_url': href,
                    'image_caption': caption,
                    'event_category': 'Gallery',
                    'event_label': caption
                });
            }
            
            // Alternative analytics tracking
            if (typeof ga !== 'undefined') {
                ga('send', 'event', 'Gallery', 'External Link Click', caption);
            }
        });
        
        // Track gallery interactions
        $('.gallery-item').on('mouseenter', function() {
            var caption = $(this).find('.gallery-caption').text();
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'gallery_hover', {
                    'image_caption': caption,
                    'event_category': 'Gallery',
                    'event_label': 'Image Hover'
                });
            }
        });
    }
    
    // Handle responsive behavior
    function handleResponsiveUpdates() {
        var $gallery = $('.responsive-gallery-grid');
        var windowWidth = $(window).width();
        
        // Add responsive classes for CSS targeting
        $gallery.removeClass('mobile tablet desktop');
        
        if (windowWidth < 768) {
            $gallery.addClass('mobile');
        } else if (windowWidth < 1024) {
            $gallery.addClass('tablet');
        } else {
            $gallery.addClass('desktop');
        }
    }
    
    // Update on window resize
    $(window).on('resize', debounce(handleResponsiveUpdates, 250));
    
    // Initial responsive setup
    handleResponsiveUpdates();
    
    // Utility function for debouncing
    function debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
    
    // Handle image loading errors
    $('.gallery-image').on('error', function() {
        $(this).attr('src', 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIG5vdCBmb3VuZDwvdGV4dD48L3N2Zz4=');
        $(this).closest('.gallery-item').addClass('image-error');
    });
    
    // Preload images on hover for better UX
    $('.gallery-item').on('mouseenter', function() {
        var $img = $(this).find('.gallery-image');
        var src = $img.attr('src');
        
        if (src && !$img.data('preloaded')) {
            var preloadImg = new Image();
            preloadImg.src = src;
            $img.data('preloaded', true);
        }
    });
    
    // Admin page enhancements
    if ($('body').hasClass('toplevel_page_responsive-gallery')) {
        // Media uploader integration (if needed)
        handleMediaUploader();
        
        // Form validation
        handleFormValidation();
    }
    
    function handleMediaUploader() {
        // WordPress media uploader integration
        if (typeof wp !== 'undefined' && wp.media) {
            var mediaUploader;
            
            $('#upload-image-btn').on('click', function(e) {
                e.preventDefault();
                
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                
                mediaUploader = wp.media({
                    title: 'Choose Image',
                    button: {
                        text: 'Choose Image'
                    },
                    multiple: false
                });
                
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#image_url').val(attachment.url);
                    $('#alt_text').val(attachment.alt || attachment.title);
                    $('#caption').val(attachment.caption || attachment.title);
                    $('#description').val(attachment.description || '');
                });
                
                mediaUploader.open();
            });
        }
    }
    
    function handleFormValidation() {
        $('.gallery-form').on('submit', function(e) {
            var isValid = true;
            var $form = $(this);
            
            // Clear previous errors
            $form.find('.error').removeClass('error');
            
            // Validate required fields
            $form.find('[required]').each(function() {
                if (!$(this).val().trim()) {
                    $(this).addClass('error');
                    isValid = false;
                }
            });
            
            // Validate URLs
            $form.find('input[type="url"]').each(function() {
                var url = $(this).val().trim();
                if (url && !isValidUrl(url)) {
                    $(this).addClass('error');
                    isValid = false;
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields with valid data.');
            }
        });
    }
    
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
});