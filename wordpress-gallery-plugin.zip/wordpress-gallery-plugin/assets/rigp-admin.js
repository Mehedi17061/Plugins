jQuery(document).ready(function($) {
    'use strict';
    
    var rigpAdmin = {
        init: function() {
            this.bindEvents();
            this.initSortable();
            this.initMediaUploader();
        },
        
        bindEvents: function() {
            // Add image form
            $('#rigp-add-form').on('submit', this.handleAddImage);
            
            // Edit image form
            $('#rigp-edit-form').on('submit', this.handleEditImage);
            
            // Delete image
            $(document).on('click', '.rigp-delete-btn', this.handleDeleteImage);
            
            // Edit image
            $(document).on('click', '.rigp-edit-btn', this.handleEditImageClick);
            
            // Clear form
            $('#rigp-clear-form').on('click', this.clearAddForm);
            
            // Modal close
            $('.rigp-modal-close').on('click', this.closeModal);
            
            // Close modal on outside click
            $('.rigp-modal').on('click', function(e) {
                if (e.target === this) {
                    rigpAdmin.closeModal();
                }
            });
            
            // Escape key to close modal
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape') {
                    rigpAdmin.closeModal();
                }
            });
        },
        
        initSortable: function() {
            $('#rigp-sortable-gallery').sortable({
                items: '.rigp-admin-item',
                cursor: 'move',
                opacity: 0.8,
                placeholder: 'rigp-sortable-placeholder',
                tolerance: 'pointer',
                update: function(event, ui) {
                    rigpAdmin.handleReorder();
                }
            });
        },
        
        initMediaUploader: function() {
            var mediaUploader;
            
            $(document).on('click', '.rigp-upload-btn, #rigp-upload-btn', function(e) {
                e.preventDefault();
                
                var $button = $(this);
                var $input = $button.siblings('input[type="url"]');
                
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                
                mediaUploader = wp.media({
                    title: 'Choose Image for Gallery',
                    button: {
                        text: 'Use This Image'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });
                
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    
                    $input.val(attachment.url);
                    
                    // Auto-fill other fields if they're empty
                    var $form = $input.closest('form');
                    var $altText = $form.find('input[name="alt_text"]');
                    var $caption = $form.find('input[name="caption"]');
                    var $description = $form.find('textarea[name="description"]');
                    
                    if (!$altText.val() && attachment.alt) {
                        $altText.val(attachment.alt);
                    } else if (!$altText.val() && attachment.title) {
                        $altText.val(attachment.title);
                    }
                    
                    if (!$caption.val() && attachment.title) {
                        $caption.val(attachment.title);
                    }
                    
                    if (!$description.val() && attachment.description) {
                        $description.val(attachment.description);
                    } else if (!$description.val() && attachment.caption) {
                        $description.val(attachment.caption);
                    }
                });
                
                mediaUploader.open();
            });
        },
        
        handleAddImage: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            
            // Validate form
            if (!rigpAdmin.validateForm($form)) {
                return;
            }
            
            // Show loading state
            $submitBtn.addClass('rigp-loading').prop('disabled', true);
            
            var formData = {
                action: 'rigp_save_image',
                nonce: rigp_admin_ajax.nonce,
                image_url: $form.find('input[name="image_url"]').val(),
                alt_text: $form.find('input[name="alt_text"]').val(),
                caption: $form.find('input[name="caption"]').val(),
                description: $form.find('textarea[name="description"]').val(),
                external_link: $form.find('input[name="external_link"]').val(),
                sort_order: $form.find('input[name="sort_order"]').val()
            };
            
            $.post(rigp_admin_ajax.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        rigpAdmin.showNotice('success', response.data.message);
                        rigpAdmin.clearAddForm();
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        rigpAdmin.showNotice('error', response.data.message);
                    }
                })
                .fail(function() {
                    rigpAdmin.showNotice('error', 'An error occurred. Please try again.');
                })
                .always(function() {
                    $submitBtn.removeClass('rigp-loading').prop('disabled', false);
                });
        },
        
        handleEditImageClick: function(e) {
            e.preventDefault();
            
            var imageId = $(this).data('id');
            var $item = $(this).closest('.rigp-admin-item');
            
            // Populate edit form
            $('#edit_image_id').val(imageId);
            $('#edit_image_url').val($item.find('img').attr('src'));
            $('#edit_alt_text').val($item.find('img').attr('alt'));
            $('#edit_caption').val($item.find('.rigp-admin-caption').text());
            $('#edit_description').val($item.find('.rigp-admin-description').text());
            
            var $link = $item.find('.rigp-admin-link');
            $('#edit_external_link').val($link.length ? $link.attr('href') : '');
            
            var order = $item.find('.rigp-order').text().replace('Order: ', '');
            $('#edit_sort_order').val(order);
            
            // Show modal
            $('#rigp-edit-modal').show();
        },
        
        handleEditImage: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            
            // Validate form
            if (!rigpAdmin.validateForm($form)) {
                return;
            }
            
            // Show loading state
            $submitBtn.addClass('rigp-loading').prop('disabled', true);
            
            var formData = {
                action: 'rigp_update_image',
                nonce: rigp_admin_ajax.nonce,
                image_id: $form.find('input[name="image_id"]').val(),
                image_url: $form.find('input[name="image_url"]').val(),
                alt_text: $form.find('input[name="alt_text"]').val(),
                caption: $form.find('input[name="caption"]').val(),
                description: $form.find('textarea[name="description"]').val(),
                external_link: $form.find('input[name="external_link"]').val(),
                sort_order: $form.find('input[name="sort_order"]').val()
            };
            
            $.post(rigp_admin_ajax.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        rigpAdmin.showNotice('success', response.data.message);
                        rigpAdmin.closeModal();
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        rigpAdmin.showNotice('error', response.data.message);
                    }
                })
                .fail(function() {
                    rigpAdmin.showNotice('error', 'An error occurred. Please try again.');
                })
                .always(function() {
                    $submitBtn.removeClass('rigp-loading').prop('disabled', false);
                });
        },
        
        handleDeleteImage: function(e) {
            e.preventDefault();
            
            if (!confirm(rigp_admin_ajax.confirm_delete)) {
                return;
            }
            
            var imageId = $(this).data('id');
            var $item = $(this).closest('.rigp-admin-item');
            
            // Show loading state
            $item.addClass('rigp-loading');
            
            var formData = {
                action: 'rigp_delete_image',
                nonce: rigp_admin_ajax.nonce,
                image_id: imageId
            };
            
            $.post(rigp_admin_ajax.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        $item.fadeOut(300, function() {
                            $(this).remove();
                            rigpAdmin.updateImageCount();
                        });
                        rigpAdmin.showNotice('success', response.data.message);
                    } else {
                        rigpAdmin.showNotice('error', response.data.message);
                        $item.removeClass('rigp-loading');
                    }
                })
                .fail(function() {
                    rigpAdmin.showNotice('error', 'An error occurred. Please try again.');
                    $item.removeClass('rigp-loading');
                });
        },
        
        handleReorder: function() {
            var order = [];
            $('#rigp-sortable-gallery .rigp-admin-item').each(function() {
                order.push($(this).data('id'));
            });
            
            var formData = {
                action: 'rigp_reorder_images',
                nonce: rigp_admin_ajax.nonce,
                order: order
            };
            
            $.post(rigp_admin_ajax.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        rigpAdmin.showNotice('success', response.data.message);
                    } else {
                        rigpAdmin.showNotice('error', response.data.message);
                    }
                })
                .fail(function() {
                    rigpAdmin.showNotice('error', 'An error occurred while reordering.');
                });
        },
        
        validateForm: function($form) {
            var isValid = true;
            
            // Clear previous errors
            $form.find('.rigp-input, .rigp-textarea').removeClass('rigp-error');
            
            // Check required fields
            $form.find('[required]').each(function() {
                if (!$(this).val().trim()) {
                    $(this).addClass('rigp-error');
                    isValid = false;
                }
            });
            
            // Validate URLs
            $form.find('input[type="url"]').each(function() {
                var url = $(this).val().trim();
                if (url && !rigpAdmin.isValidUrl(url)) {
                    $(this).addClass('rigp-error');
                    isValid = false;
                }
            });
            
            if (!isValid) {
                rigpAdmin.showNotice('error', 'Please fill in all required fields with valid data.');
            }
            
            return isValid;
        },
        
        isValidUrl: function(string) {
            try {
                new URL(string);
                return true;
            } catch (_) {
                return false;
            }
        },
        
        clearAddForm: function() {
            $('#rigp-add-form')[0].reset();
            $('#rigp-add-form .rigp-input, #rigp-add-form .rigp-textarea').removeClass('rigp-error');
        },
        
        closeModal: function() {
            $('.rigp-modal').hide();
            $('#rigp-edit-form')[0].reset();
            $('#rigp-edit-form .rigp-input, #rigp-edit-form .rigp-textarea').removeClass('rigp-error');
        },
        
        showNotice: function(type, message) {
            var $notice = $('<div class="rigp-notice rigp-notice-' + type + '">' + message + '</div>');
            $('.rigp-admin-container').prepend($notice);
            
            setTimeout(function() {
                $notice.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        },
        
        updateImageCount: function() {
            var count = $('#rigp-sortable-gallery .rigp-admin-item').length;
            $('.rigp-count').text('(' + count + ')');
            
            if (count === 0) {
                $('.rigp-gallery-section').html('<h2>Current Images <span class="rigp-count">(0)</span></h2><div class="rigp-empty-state"><svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21,15 16,10 5,21"></polyline></svg><h3>No images found</h3><p>Add some images to get started with your gallery!</p></div>');
            }
        }
    };
    
    // Initialize admin functionality
    rigpAdmin.init();
    
    // Add CSS for error states
    $('<style>')
        .prop('type', 'text/css')
        .html('.rigp-input.rigp-error, .rigp-textarea.rigp-error { border-color: #ef4444 !important; box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1) !important; }')
        .appendTo('head');
});