<?php
/**
 * Plugin Name: Responsive Image Gallery Pro
 * Plugin URI: https://yourwebsite.com
 * Description: A responsive image gallery with hover effects showing captions, descriptions, and external links. Shows 4 images on desktop, 3 on tablet, and 2 on mobile.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ResponsiveImageGalleryPro {
    
    private $table_name;
    private $plugin_prefix = 'rigp_';
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'rigp_gallery_images';
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_shortcode('rigp_gallery', array($this, 'gallery_shortcode'));
        add_action('wp_ajax_rigp_save_image', array($this, 'ajax_save_image'));
        add_action('wp_ajax_rigp_delete_image', array($this, 'ajax_delete_image'));
        add_action('wp_ajax_rigp_update_image', array($this, 'ajax_update_image'));
        add_action('wp_ajax_rigp_reorder_images', array($this, 'ajax_reorder_images'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        register_activation_hook(__FILE__, array($this, 'create_gallery_table'));
        register_deactivation_hook(__FILE__, array($this, 'cleanup_plugin'));
    }
    
    public function enqueue_frontend_scripts() {
        wp_enqueue_style('rigp-gallery-css', plugin_dir_url(__FILE__) . 'assets/rigp-style.css', array(), '1.0.0');
        wp_enqueue_script('rigp-gallery-js', plugin_dir_url(__FILE__) . 'assets/rigp-script.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('rigp-gallery-js', 'rigp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rigp_nonce')
        ));
    }
    
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_rigp-gallery') {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_style('rigp-admin-css', plugin_dir_url(__FILE__) . 'assets/rigp-admin.css', array(), '1.0.0');
        wp_enqueue_script('rigp-admin-js', plugin_dir_url(__FILE__) . 'assets/rigp-admin.js', array('jquery', 'jquery-ui-sortable'), '1.0.0', true);
        
        wp_localize_script('rigp-admin-js', 'rigp_admin_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rigp_admin_nonce'),
            'confirm_delete' => __('Are you sure you want to delete this image?', 'rigp')
        ));
    }
    
    public function create_gallery_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            image_url varchar(500) NOT NULL,
            alt_text varchar(255) NOT NULL,
            caption varchar(255) NOT NULL,
            description text NOT NULL,
            external_link varchar(500) DEFAULT '',
            sort_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY sort_order (sort_order)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function cleanup_plugin() {
        // Optional: Remove table on deactivation (uncomment if needed)
        // global $wpdb;
        // $wpdb->query("DROP TABLE IF EXISTS {$this->table_name}");
    }
    
    public function gallery_shortcode($atts) {
        global $wpdb;
        
        $atts = shortcode_atts(array(
            'limit' => -1,
            'orderby' => 'sort_order',
            'order' => 'ASC',
            'class' => ''
        ), $atts);
        
        $limit_sql = $atts['limit'] > 0 ? "LIMIT " . intval($atts['limit']) : "";
        $orderby = sanitize_sql_orderby($atts['orderby'] . ' ' . $atts['order']);
        
        $images = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_name} ORDER BY {$orderby} {$limit_sql}")
        );
        
        if (empty($images)) {
            return '<div class="rigp-no-images"><p>' . __('No images found in gallery.', 'rigp') . '</p></div>';
        }
        
        $additional_class = !empty($atts['class']) ? ' ' . sanitize_html_class($atts['class']) : '';
        
        ob_start();
        ?>
        <div class="rigp-gallery-container<?php echo $additional_class; ?>">
            <div class="rigp-gallery-grid">
                <?php foreach ($images as $image): ?>
                    <div class="rigp-gallery-item" data-rigp-id="<?php echo esc_attr($image->id); ?>">
                        <div class="rigp-image-wrapper">
                            <img src="<?php echo esc_url($image->image_url); ?>" 
                                 alt="<?php echo esc_attr($image->alt_text); ?>" 
                                 class="rigp-gallery-image" 
                                 loading="lazy">
                            
                            <div class="rigp-overlay">
                                <div class="rigp-content">
                                    <?php if (!empty($image->external_link)): ?>
                                        <div class="rigp-link-wrapper">
                                            <a href="<?php echo esc_url($image->external_link); ?>" 
                                               target="_blank" 
                                               rel="noopener noreferrer" 
                                               class="rigp-link-btn"
                                               aria-label="<?php echo esc_attr(sprintf(__('Open external link for %s', 'rigp'), $image->caption)); ?>">
                                                <svg class="rigp-link-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                                    <polyline points="15,3 21,3 21,9"></polyline>
                                                    <line x1="10" y1="14" x2="21" y2="3"></line>
                                                </svg>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="rigp-text">
                                        <h3 class="rigp-caption"><?php echo esc_html($image->caption); ?></h3>
                                        <p class="rigp-description"><?php echo esc_html($image->description); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('RIGP Gallery', 'rigp'),
            __('RIGP Gallery', 'rigp'),
            'manage_options',
            'rigp-gallery',
            array($this, 'admin_page'),
            'dashicons-format-gallery',
            30
        );
    }
    
    public function admin_page() {
        global $wpdb;
        
        $images = $wpdb->get_results("SELECT * FROM {$this->table_name} ORDER BY sort_order ASC, id ASC");
        ?>
        <div class="wrap rigp-admin-wrap">
            <h1><?php _e('Responsive Image Gallery Pro', 'rigp'); ?></h1>
            
            <div class="rigp-admin-container">
                <div class="rigp-shortcode-info">
                    <h3><?php _e('Usage', 'rigp'); ?></h3>
                    <p><?php _e('Use the shortcode', 'rigp'); ?> <code>[rigp_gallery]</code> <?php _e('to display the gallery on any page or post.', 'rigp'); ?></p>
                    <p><?php _e('Optional parameters:', 'rigp'); ?></p>
                    <ul>
                        <li><code>[rigp_gallery limit="8"]</code> - <?php _e('Limit number of images', 'rigp'); ?></li>
                        <li><code>[rigp_gallery orderby="caption" order="DESC"]</code> - <?php _e('Custom ordering', 'rigp'); ?></li>
                        <li><code>[rigp_gallery class="custom-class"]</code> - <?php _e('Add custom CSS class', 'rigp'); ?></li>
                    </ul>
                </div>
                
                <div class="rigp-admin-sections">
                    <div class="rigp-add-section">
                        <h2><?php _e('Add New Image', 'rigp'); ?></h2>
                        <form id="rigp-add-form" class="rigp-form">
                            <div class="rigp-form-row">
                                <div class="rigp-form-group">
                                    <label for="rigp_image_url"><?php _e('Image URL', 'rigp'); ?> *</label>
                                    <div class="rigp-input-group">
                                        <input type="url" id="rigp_image_url" name="image_url" class="rigp-input" required>
                                        <button type="button" id="rigp-upload-btn" class="rigp-btn rigp-btn-secondary"><?php _e('Upload', 'rigp'); ?></button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="rigp-form-row">
                                <div class="rigp-form-group">
                                    <label for="rigp_alt_text"><?php _e('Alt Text', 'rigp'); ?> *</label>
                                    <input type="text" id="rigp_alt_text" name="alt_text" class="rigp-input" required>
                                </div>
                                <div class="rigp-form-group">
                                    <label for="rigp_caption"><?php _e('Caption', 'rigp'); ?> *</label>
                                    <input type="text" id="rigp_caption" name="caption" class="rigp-input" required>
                                </div>
                            </div>
                            
                            <div class="rigp-form-row">
                                <div class="rigp-form-group rigp-full-width">
                                    <label for="rigp_description"><?php _e('Description', 'rigp'); ?> *</label>
                                    <textarea id="rigp_description" name="description" rows="3" class="rigp-textarea" required></textarea>
                                </div>
                            </div>
                            
                            <div class="rigp-form-row">
                                <div class="rigp-form-group">
                                    <label for="rigp_external_link"><?php _e('External Link', 'rigp'); ?></label>
                                    <input type="url" id="rigp_external_link" name="external_link" class="rigp-input">
                                </div>
                                <div class="rigp-form-group">
                                    <label for="rigp_sort_order"><?php _e('Sort Order', 'rigp'); ?></label>
                                    <input type="number" id="rigp_sort_order" name="sort_order" value="0" min="0" class="rigp-input">
                                </div>
                            </div>
                            
                            <div class="rigp-form-actions">
                                <button type="submit" class="rigp-btn rigp-btn-primary"><?php _e('Add Image', 'rigp'); ?></button>
                                <button type="button" id="rigp-clear-form" class="rigp-btn rigp-btn-secondary"><?php _e('Clear Form', 'rigp'); ?></button>
                            </div>
                        </form>
                    </div>
                    
                    <div class="rigp-gallery-section">
                        <h2><?php _e('Current Images', 'rigp'); ?> <span class="rigp-count">(<?php echo count($images); ?>)</span></h2>
                        
                        <?php if (!empty($images)): ?>
                            <div class="rigp-gallery-actions">
                                <p class="rigp-help-text"><?php _e('Drag and drop images to reorder them.', 'rigp'); ?></p>
                            </div>
                            
                            <div id="rigp-sortable-gallery" class="rigp-admin-grid">
                                <?php foreach ($images as $image): ?>
                                    <div class="rigp-admin-item" data-id="<?php echo esc_attr($image->id); ?>">
                                        <div class="rigp-admin-image">
                                            <img src="<?php echo esc_url($image->image_url); ?>" alt="<?php echo esc_attr($image->alt_text); ?>">
                                            <div class="rigp-admin-overlay">
                                                <button class="rigp-edit-btn" data-id="<?php echo esc_attr($image->id); ?>" title="<?php _e('Edit', 'rigp'); ?>">
                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                                    </svg>
                                                </button>
                                                <button class="rigp-delete-btn" data-id="<?php echo esc_attr($image->id); ?>" title="<?php _e('Delete', 'rigp'); ?>">
                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <polyline points="3,6 5,6 21,6"></polyline>
                                                        <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="rigp-admin-info">
                                            <strong class="rigp-admin-caption"><?php echo esc_html($image->caption); ?></strong>
                                            <p class="rigp-admin-description"><?php echo esc_html(wp_trim_words($image->description, 15)); ?></p>
                                            <?php if ($image->external_link): ?>
                                                <a href="<?php echo esc_url($image->external_link); ?>" target="_blank" class="rigp-admin-link"><?php _e('External Link', 'rigp'); ?></a>
                                            <?php endif; ?>
                                            <div class="rigp-admin-meta">
                                                <span class="rigp-order"><?php _e('Order:', 'rigp'); ?> <?php echo esc_html($image->sort_order); ?></span>
                                                <span class="rigp-id">ID: <?php echo esc_html($image->id); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="rigp-empty-state">
                                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                    <circle cx="8.5" cy="8.5" r="1.5"></circle>
                                    <polyline points="21,15 16,10 5,21"></polyline>
                                </svg>
                                <h3><?php _e('No images found', 'rigp'); ?></h3>
                                <p><?php _e('Add some images to get started with your gallery!', 'rigp'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Edit Modal -->
        <div id="rigp-edit-modal" class="rigp-modal" style="display: none;">
            <div class="rigp-modal-content">
                <div class="rigp-modal-header">
                    <h3><?php _e('Edit Image', 'rigp'); ?></h3>
                    <button class="rigp-modal-close">&times;</button>
                </div>
                <form id="rigp-edit-form" class="rigp-form">
                    <input type="hidden" id="edit_image_id" name="image_id">
                    
                    <div class="rigp-form-row">
                        <div class="rigp-form-group rigp-full-width">
                            <label for="edit_image_url"><?php _e('Image URL', 'rigp'); ?> *</label>
                            <div class="rigp-input-group">
                                <input type="url" id="edit_image_url" name="image_url" class="rigp-input" required>
                                <button type="button" class="rigp-upload-btn rigp-btn rigp-btn-secondary"><?php _e('Upload', 'rigp'); ?></button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="rigp-form-row">
                        <div class="rigp-form-group">
                            <label for="edit_alt_text"><?php _e('Alt Text', 'rigp'); ?> *</label>
                            <input type="text" id="edit_alt_text" name="alt_text" class="rigp-input" required>
                        </div>
                        <div class="rigp-form-group">
                            <label for="edit_caption"><?php _e('Caption', 'rigp'); ?> *</label>
                            <input type="text" id="edit_caption" name="caption" class="rigp-input" required>
                        </div>
                    </div>
                    
                    <div class="rigp-form-row">
                        <div class="rigp-form-group rigp-full-width">
                            <label for="edit_description"><?php _e('Description', 'rigp'); ?> *</label>
                            <textarea id="edit_description" name="description" rows="3" class="rigp-textarea" required></textarea>
                        </div>
                    </div>
                    
                    <div class="rigp-form-row">
                        <div class="rigp-form-group">
                            <label for="edit_external_link"><?php _e('External Link', 'rigp'); ?></label>
                            <input type="url" id="edit_external_link" name="external_link" class="rigp-input">
                        </div>
                        <div class="rigp-form-group">
                            <label for="edit_sort_order"><?php _e('Sort Order', 'rigp'); ?></label>
                            <input type="number" id="edit_sort_order" name="sort_order" min="0" class="rigp-input">
                        </div>
                    </div>
                    
                    <div class="rigp-modal-actions">
                        <button type="submit" class="rigp-btn rigp-btn-primary"><?php _e('Update Image', 'rigp'); ?></button>
                        <button type="button" class="rigp-modal-close rigp-btn rigp-btn-secondary"><?php _e('Cancel', 'rigp'); ?></button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }
    
    public function ajax_save_image() {
        check_ajax_referer('rigp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized access', 'rigp'));
        }
        
        global $wpdb;
        
        $data = array(
            'image_url' => sanitize_url($_POST['image_url']),
            'alt_text' => sanitize_text_field($_POST['alt_text']),
            'caption' => sanitize_text_field($_POST['caption']),
            'description' => sanitize_textarea_field($_POST['description']),
            'external_link' => sanitize_url($_POST['external_link']),
            'sort_order' => intval($_POST['sort_order'])
        );
        
        $result = $wpdb->insert($this->table_name, $data);
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Image added successfully!', 'rigp'),
                'id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error adding image. Please try again.', 'rigp')
            ));
        }
    }
    
    public function ajax_update_image() {
        check_ajax_referer('rigp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized access', 'rigp'));
        }
        
        global $wpdb;
        
        $image_id = intval($_POST['image_id']);
        $data = array(
            'image_url' => sanitize_url($_POST['image_url']),
            'alt_text' => sanitize_text_field($_POST['alt_text']),
            'caption' => sanitize_text_field($_POST['caption']),
            'description' => sanitize_textarea_field($_POST['description']),
            'external_link' => sanitize_url($_POST['external_link']),
            'sort_order' => intval($_POST['sort_order'])
        );
        
        $result = $wpdb->update($this->table_name, $data, array('id' => $image_id));
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Image updated successfully!', 'rigp')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error updating image. Please try again.', 'rigp')
            ));
        }
    }
    
    public function ajax_delete_image() {
        check_ajax_referer('rigp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized access', 'rigp'));
        }
        
        global $wpdb;
        
        $image_id = intval($_POST['image_id']);
        $result = $wpdb->delete($this->table_name, array('id' => $image_id));
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Image deleted successfully!', 'rigp')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error deleting image. Please try again.', 'rigp')
            ));
        }
    }
    
    public function ajax_reorder_images() {
        check_ajax_referer('rigp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized access', 'rigp'));
        }
        
        global $wpdb;
        
        $order = $_POST['order'];
        
        foreach ($order as $index => $image_id) {
            $wpdb->update(
                $this->table_name,
                array('sort_order' => $index),
                array('id' => intval($image_id))
            );
        }
        
        wp_send_json_success(array(
            'message' => __('Images reordered successfully!', 'rigp')
        ));
    }
}

// Initialize the plugin
new ResponsiveImageGalleryPro();
?>